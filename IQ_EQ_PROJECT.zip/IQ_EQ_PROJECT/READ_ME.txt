			IQ_EQ

My final year project which also features components added by my other team members which I will list below.

GAVIN CAMPBELL: 2 PLAYER NETWORK FUNCTIONALITY, 
		BULLET GRAPH (ommitted in this build)

CONOR MASTERSON: GRAPHS (BAR, LINE, COMBINED BAR and LINE), 
		 Web services (ommitted in this build),
		 IMAGE DOWNLOAD (ommitted)

All other code was written by myself.

In this folder you will find a .rar file and a .ccgame file. Extract the .rar file and open to find all source files, content and a project file. The Project file should be opened with visual C# 2005 express edition, you also must have XNA game studio 2.0 express installed along with service pack 1 for visual studio.
***UPDATE*** I added an xna redistributable installer so you no longer need to install C# express, game studio or sp1. However if you have any problems you are better off just downloading and installing them.

If you just want to run the game then double click on IQ_EQ_windows.ccgame and unpack to find an executable (You still must have the XNA framework installed on your computer).



			BRIEF OVERVIEW

The application  contains 2 different types of games, an IQ game and an EQ game. In the IQ game you are presented with an active sequence of images whereby you must click if you saw the same image n images ago. The default "n_back" is set to 2 so this means you must click if you saw the same image 2 images ago. If you click correctly a green light will flash. If you guess incorrectly or miss a match then the red light flashes. As you keep clicking correctly, distractor images will start to appear on the screen which increases difficulty. Their alpha levels decline if you guess incorrectly or miss an n_back match. When the game ends your response speeds are displayed on a bar graph.
The IQ games are fully tweakable by the user in the options screen, number of distractor images can be set, the  "n_back" can be set, the update speed of the sequence, the number of active sequences to track can be set among other options. If you want to play with custom variables then click on custom when selecting a level.

The second game is the EQ DECONDITIONING game whereby the user is presented with a set of images. The images are composed of negative stimuli and one positive stimuli. The user must click on the positive stimuli as fast as possible. When the user clicks on the positive stimuli the next sequence of images are presented. When the game ends the user is presented with their response times.
Like the IQ game, negative and positive stimuli image packs can be loaded via XML files by the user. All other game variables are also tweakable in options.   

	

KNOWN ISSUES:

The games resolution is locked at 1280 x 720. If the resolution of your PC is not at least 1280 x 720 then the game window will scale down to your desktop resolution but the native resolution of the game will still be 1280x720 and this will mess up the GUI (button positions will not match up with their visual representations).

***MAKE SURE YOUR DESKTOP RESOLUTION IS AT LEAST 1280 x 720*** 

Also, some elements of the bar graphs will not be drawn on some PC's (mainly laptops)

Multiplayer cannot be played or tested on the same computer as the game relies on an xna live proxy which only allows one instance on each computer. It works fine across a network.






















	 