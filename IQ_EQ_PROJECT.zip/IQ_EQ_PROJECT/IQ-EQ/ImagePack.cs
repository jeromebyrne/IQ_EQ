using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using System.Xml;

namespace IQ_EQ
{
    public class ImagePack
    {
        #region variables -----------------------------

        /// <summary>
        /// a list of all the images in this image pack
        /// </summary>
        List<Texture2D> m_imageList = new List<Texture2D>();

        #endregion ------------------------------------


        #region properties ----------------------------

        /// <summary>
        /// returns the list of images from this image pack
        /// </summary>
        public List<Texture2D> ImageList { get { return m_imageList; } }

        #endregion ------------------------------------


        #region functions -----------------------------

        /// <summary>
        /// Constructor. Loads up images from xml data 
        /// </summary>
        /// <param name="xmlFile">the xml file which contains paths for images</param>
        public ImagePack(string xmlFile)
        {
            // make sure our xml file is valid
            if (xmlFile == null)
            {
                throw new Exception("Xml file is null");
            }

            // check that the string is not empty
            if (xmlFile.Length == 0)
            {
                throw new Exception("The xml string name is empty");
            }

            // create a new xml document
            XmlDocument doc = new XmlDocument();

            // load up the xml file
            doc.Load(xmlFile);

            if(doc == null)
            {
                throw new Exception("Xml document is null in ImagePack constructor");
            }

            XmlNode root = doc.FirstChild;

            // go through all the nodes in the xml file
            foreach(XmlNode node in root.ChildNodes)
            {
                // get the text in between
                string texturePath = node.InnerText;

                // and load the texture 
                Texture2D loadedTexture = Core.Graphics.LoadTexture(texturePath);

                // now add the texture to our list
                m_imageList.Add(loadedTexture);
            }
        }

        /// <summary>
        /// pull a random image from the image list
        /// </summary>
        /// <returns>the texture that is selected randomly</returns>
        public Texture2D GetRandomImage()
        {
            Texture2D selected = null;

            // get the number of images available
            int numImages = m_imageList.Count;

            // get a random number
            int random = Core.Random.Next(numImages);

            // now use this to find the texture in the list
            selected = m_imageList[random]; 

            return selected;
        }


        #endregion ------------------------------------
    }
}
