using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace IQ_EQ
{
    /// <summary>
    /// Manages all media placeholders in the game at any one time,
    /// updates, draws them and does collision detection between the placeholders
    /// </summary>
    public class MediaPlaceholderManager
    {
        #region variables ============================

        /// <summary>
        /// holds all the media placeholders in the game
        /// </summary>
        List<MediaPlaceholder> m_placeholderList = null;

        /// <summary>
        /// holds all the media placeholders in the game
        /// </summary>
        List<MediaPlaceholder> m_clientPlaceholderList = new List<MediaPlaceholder>();

        /// <summary>
        /// holds a list of lists which contain the image indices for each placeholder in an.
        /// </summary>
        List<List<int>> m_imageLists = null;

        /// <summary>
        /// the current index to the images in the index lists
        /// </summary>
        List<int> m_currentImageListIndex = null;

        /// <summary>
        /// the number of images back to test against
        /// </summary>
        int m_nback = 2;

        /// <summary>
        /// did we just guess correct
        /// </summary>
        bool m_justGuessedCorrect = false;

        /// <summary>
        /// did we just guess wrong
        /// </summary>
        bool m_justGuessedWrong = false;

        int incrementChanceSize = 7;
        int decrementChanceSize = 7;

        /// <summary>
        /// the image of the green tick, this needs to be accessable due to its changing alpha values
        /// </summary>
        Sprite m_tickSprite = null;

        /// <summary>
        /// the image of the red cross, this needs to be accessable due to its changing alpha values
        /// </summary>
        Sprite m_crossSprite = null;

        /// <summary>
        /// the image which is placed over the right and wrong lights in the game
        /// </summary>
        Sprite m_lightSurfaceSprite1 = null;

        /// <summary>
        /// the image which is placed over the right and wrong lights in the game
        /// </summary>
        Sprite m_lightSurfaceSprite2 = null;

        /// <summary>
        /// the positive image pack during an eq game
        /// </summary>
        ImagePack m_positiveImagePack_eq = null;

        /// <summary>
        /// the negative image pack during an eq game
        /// </summary>
        ImagePack m_negativeImagePack_eq = null;

        /// <summary>
        /// the placeholder which displays the positive stimuli in an EQ game
        /// </summary>
        MediaPlaceholder m_positivePlaceholder_EQ = null;

        /// <summary>
        /// have we clicked on a correct eq game image
        /// </summary>
        bool m_displayingCorrectImage_EQ = false;

        /// <summary>
        /// the time in milliseconds that a correct image is shown for in the EQ game
        /// </summary>
        int M_DISPLAY_CORRECT_TIME_EQ = 500;

        /// <summary>
        /// the time at which we started to display the correct image in an 
        /// </summary>
        int m_startedDisplayCorrect_EQ = 0;

        /// <summary>
        /// dimensions of the placeholder in the current game
        /// </summary>
        Vector2 m_dimensions = new Vector2(300, 300);

        /// <summary>
        /// the initial position of positive placeholder in the EQ game
        /// </summary>
        Vector2 m_positiveInitialPos_EQ = new Vector2(0, 0);

        /// <summary>
        /// the image of the green tick for the client, this needs to be accessable due to its changing alpha values
        /// </summary>
        Sprite m_clientTickSprite = null;

        /// <summary>
        /// the image of the red cross for the client, this needs to be accessable due to its changing alpha values
        /// </summary>
        Sprite m_clientCrossSprite = null;

        /// <summary>
        /// flags initialisation of the multiplayer IQ game for the server
        /// </summary>
        bool m_serverMultIQSetUp = false;

        /// <summary>
        /// flags initialisation of the multiplayer IQ game for the client
        /// </summary>
        bool m_clientMultIQSetUp = false;

        /// <summary>
        /// the number of placeholders to have on screen
        /// </summary>
        int m_numPlaceholdersMulti = 0;

        /// <summary>
        /// Number of sequences for the multiplayer game
        /// </summary>
        int m_numSequencesMult = 50;

        /// <summary>
        /// keeps track of the active placeholder for multiplayer
        /// </summary>
        MediaPlaceholder m_activePlaceholderMulti = null;

        /// <summary>
        /// a placeholder which is created when the player clicks correctly and moves towards the centre and then dissapears
        /// </summary>
        MediaPlaceholder m_displayCorrectPlaceholder = new MediaPlaceholder();

        /// <summary>
        /// the length of time the lights flash for
        /// </summary>
        int M_LIGHT_FLASH_TIME = 300;

        /// <summary>
        /// the time the green light started flashing
        /// </summary>
        int m_greenLightStartFlashTime = 0;

        /// <summary>
        /// the time the red light started flashing
        /// </summary>
        int m_redLightStartFlashTime = 0;

        bool m_greenLightIsFlashing = false;

        bool m_redLightIsFlashing = false;

        #endregion ===================================

        #region properties ===========================

        /// <summary>
        /// return sthe nback value
        /// </summary>
        public int N_Back { get { return m_nback; } }

        /// <summary>
        /// returns true if we just guessed correctly
        /// </summary>
        public bool JustGuessedCorrectly { get { return m_justGuessedCorrect; } }

        /// <summary>
        /// returns true if we just guessed wrongly
        /// </summary>
        public bool JustGuessedWrongly { get { return m_justGuessedWrong; } }

        /// <summary>
        /// return the main placeholder list
        /// </summary>
        public List<MediaPlaceholder> PlaceholderList { get { return m_placeholderList; } }

        /// <summary>
        /// return the client placeholder list
        /// </summary>
        public List<MediaPlaceholder> ClientPlaceholderList { get { return m_clientPlaceholderList; } }

        /// <summary>
        /// return the imageLists of indices for the placeholders
        /// </summary>
        public List<List<int>> ImageLists { get { return m_imageLists; } }

        /// <summary>
        /// return the list of current indices
        /// </summary>
        public List<int> CurrentImageListIndex { get { return m_currentImageListIndex; } }

        /// <summary>
        /// return the list of current indices
        /// </summary>
        public bool ServerMultIQSetUp { get { return m_serverMultIQSetUp; } }

        /// <summary>
        /// return the list of current indices
        /// </summary>
        public bool ClientMultIQSetUp { get { return m_clientMultIQSetUp; } }

        /// <summary>
        /// return the list of current indices
        /// </summary>
        public int NumPlaceholders { get { return m_numPlaceholdersMulti; } }

        /// <summary>
        /// return the correct light sprite
        /// </summary>
        public Sprite CorrectLightSprite { get { return m_tickSprite; } }

        /// <summary>
        /// return the wrong light sprite
        /// </summary>
        public Sprite WrongLightSprite { get { return m_crossSprite; } }

        /// <summary>
        /// return the correct light sprite for the client
        /// </summary>
        public Sprite ClientCorrectLightSprite { get { return m_clientTickSprite; } }

        /// <summary>
        /// return the wrong light sprite for the client
        /// </summary>
        public Sprite ClientWrongLightSprite { get { return m_clientCrossSprite; } }



        #endregion ===================================

        #region functions ============================

        /// <summary>
        /// constructor
        /// </summary>
        public MediaPlaceholderManager()
        {

        }
        public void Initialise()
        {
            m_tickSprite = new Sprite(false, false);
            m_tickSprite.Dimensions = new Vector2(75, 75);
            m_tickSprite.Position = new Vector2(500, -110);
            m_tickSprite.Texture = Core.Graphics.LoadTexture("Graphics/Themes/Default/Gui/correct");
            m_tickSprite.Alpha = 12;

            m_crossSprite = new Sprite(false, false);
            m_crossSprite.Dimensions = new Vector2(75, 75);
            m_crossSprite.Position = new Vector2(500, -200);
            m_crossSprite.Texture = Core.Graphics.LoadTexture("Graphics/Themes/Default/Gui/wrong");
            m_crossSprite.Alpha = 12;

            m_lightSurfaceSprite1 = new Sprite(false, false);
            m_lightSurfaceSprite1.Dimensions = new Vector2(75, 75);
            m_lightSurfaceSprite1.Position = new Vector2(500, -110);
            m_lightSurfaceSprite1.Texture = Core.Graphics.LoadTexture("Graphics/Themes/Default/Gui/LightSurface");

            m_lightSurfaceSprite2 = new Sprite(false, false);
            m_lightSurfaceSprite2.Dimensions = new Vector2(75, 75);
            m_lightSurfaceSprite2.Position = new Vector2(500, -200);
            m_lightSurfaceSprite2.Texture = Core.Graphics.LoadTexture("Graphics/Themes/Default/Gui/LightSurface");

            m_clientTickSprite = new Sprite(false, false);
            m_clientTickSprite.Dimensions = new Vector2(75, 75);
            m_clientTickSprite.Position = new Vector2(500, -110);
            m_clientTickSprite.Texture = Core.Graphics.LoadTexture("Graphics/Themes/Default/Gui/correct");
            m_clientTickSprite.Alpha = 64;

            m_clientCrossSprite = new Sprite(false, false);
            m_clientCrossSprite.Dimensions = new Vector2(75, 75);
            m_clientCrossSprite.Position = new Vector2(500, -200);
            m_clientCrossSprite.Texture = Core.Graphics.LoadTexture("Graphics/Themes/Default/Gui/wrong");
            m_clientCrossSprite.Alpha = 64;

        }

        /// <summary>
        /// adds a media placeholder to the list of placholders 
        /// </summary>
        /// <param name="placeholder">the placeholder to be added</param>
        public void AddPlaceholder(MediaPlaceholder placeholder)
        {
            // find out how many placeholders are in the game and assign an index
            int index = 0;

            foreach (MediaPlaceholder ph in m_placeholderList)
            {
                index++;
            }

            placeholder.Index = index;

            // now add the placeholder
            m_placeholderList.Add(placeholder);

            foreach (MediaPlaceholder m in m_placeholderList)
            {
                // make the first placeholder the active one
                m.Highlighted = true;
                break;
            }

            placeholder.Reset();
        }

        /// <summary>
        /// adds a media placeholder to the list of placholders 
        /// </summary>
        /// <param name="placeholder">the placeholder to be added</param>
        public void AddPlaceholderForClient(MediaPlaceholder placeholder)
        {
            // find out how many placeholders are in the game and assign an index
            int index = 0;

            foreach (MediaPlaceholder ph in m_clientPlaceholderList)
            {
                index++;
            }

            placeholder.Index = index;

            placeholder.IsClientPlaceholder = true;

            // now add the placeholder
            m_clientPlaceholderList.Add(placeholder);

            foreach (MediaPlaceholder m in m_clientPlaceholderList)
            {
                // make the first placeholder the active one
                m.Highlighted = true;
                break;
            }

            //// create a new list of indices for this placeholder
            //m_imageLists.Add(new List<int>());

            placeholder.Reset();
        }

        /// <summary>
        /// draws everything associated with the 1q game
        /// </summary>
        public void Draw_IQgame()
        {
            // set the alpha value of the tick and cross appropriately
            if (m_greenLightIsFlashing && Core.Timing.TotalTime < m_greenLightStartFlashTime + M_LIGHT_FLASH_TIME)
            {
                m_tickSprite.Alpha = 255;
            }
            else { m_tickSprite.Alpha = 25; }
            if (m_redLightIsFlashing && Core.Timing.TotalTime < m_redLightStartFlashTime + M_LIGHT_FLASH_TIME)
            {
                m_crossSprite.Alpha = 255;
            }
            else { m_crossSprite.Alpha = 25; }

            if (Core.Timing.TotalTime > m_redLightStartFlashTime + M_LIGHT_FLASH_TIME)
            {
                m_redLightIsFlashing = false;
            }
            if (Core.Timing.TotalTime > m_greenLightStartFlashTime + M_LIGHT_FLASH_TIME)
            {
                m_greenLightIsFlashing = false;
            }

            m_tickSprite.Draw();
            m_crossSprite.Draw();
            m_lightSurfaceSprite1.Draw();
            m_lightSurfaceSprite2.Draw();

            foreach (MediaPlaceholder ph in m_placeholderList)
            {
                ph.Draw();
            }

            //Gui.SpriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.BackToFront, SaveStateMode.SaveState);

            //Gui.OutText("current image index: ", m_currentImageListIndex[0].ToString(), 200, 200, Color.Black);

            //Gui.SpriteBatch.End();
        }

        /// <summary>
        /// draws everything associated with the 1q game
        /// </summary>
        public void Draw_MultIQgame()
        {
            // set the alpha value of the tick and cross appropriately
            if (m_justGuessedCorrect) { m_tickSprite.Alpha = 255; }
            else { m_tickSprite.Alpha = 64; }
            if (m_justGuessedWrong) { m_crossSprite.Alpha = 255; }
            else { m_crossSprite.Alpha = 64; }

            foreach (MediaPlaceholder ph in m_clientPlaceholderList)
            {
                ph.Draw();
            }

            if (Core.m_isServer)
            {
                // For the Multiplayer game, handle alpha setting separately
                // This is usually done in MediaPlaceholder, but we want different
                // functionaltiy for client and server placeholders
                foreach (MediaPlaceholder ph in m_placeholderList)
                {
                    if (ph.Highlighted)
                    {
                        ph.Image.Alpha = 255;
                    }
                    else
                    {
                        ph.Image.Alpha = (int)(Core.Stats.ChanceOfPlaceholderSwitch * 2.55f);
                    }
                }
            }

            m_clientTickSprite.Draw();
            m_clientCrossSprite.Draw();
            m_lightSurfaceSprite1.Draw();
            m_lightSurfaceSprite2.Draw();
        }

        /// <summary>
        /// draws all entities associated with an eq game
        /// </summary>
        public void Draw_EQgame()
        {
            // set the alpha value of the tick and cross appropriately
            if (m_justGuessedCorrect) { m_tickSprite.Alpha = 255; }
            else { m_tickSprite.Alpha = 25; }
            if (m_justGuessedWrong) { m_crossSprite.Alpha = 255; }
            else { m_crossSprite.Alpha = 25; }

            //m_tickSprite.Draw();
            //m_crossSprite.Draw();
            //m_lightSurfaceSprite1.Draw();
            //m_lightSurfaceSprite2.Draw();

            foreach (MediaPlaceholder ph in m_placeholderList)
            {
                ph.Draw();
            }

            if (m_displayingCorrectImage_EQ && m_displayCorrectPlaceholder != null)
            {
                m_displayCorrectPlaceholder.Draw();
            }

        }

        /// <summary>
        /// randomly selects a new active placeholder (makes sure not to select the same one again)
        /// </summary>
        public void SwitchPlaceholders(MediaPlaceholder current, MediaPlaceholder newHolder)
        {
            Vector2 currentPos = current.Position;
            Vector2 newPos = newHolder.Position;


            // switch positions
            current.Position = newPos;
            newHolder.Position = currentPos;
        }

        /// <summary>
        /// check user input on a specified placehlder, check if its a correct guess etc
        /// </summary>
        /// <param name="placeholder">the placeholder to check input on</param>
        private void CheckInput_IQ(MediaPlaceholder placeholder)
        {
            int width = Core.Graphics.DeviceManager.PreferredBackBufferWidth;
            int height = Core.Graphics.DeviceManager.PreferredBackBufferHeight;

            Vector2 worldArea = Core.Camera.GetWorldArea();

            //========= Input ======================================
            // get the keys states
            MouseState ms = Mouse.GetState();

            //We need to convert the placeholder position into screen position 
            int posX = (int)placeholder.X + (int)worldArea.X / 2;
            int posY = (int)placeholder.Y + (int)worldArea.Y / 2;

            int mouseX = ms.X;
            int mouseY = (int)worldArea.Y - ms.Y;

            float right = posX + (placeholder.Dimensions.X / 2);
            float left = posX - (placeholder.Dimensions.X / 2);
            float top = posY - (placeholder.Dimensions.Y / 2);
            float bottom = posY + (placeholder.Dimensions.Y / 2);

            // if we are clicking on this placeholder
            if (ms.LeftButton == ButtonState.Pressed && !placeholder.MatchChecked)
            {
                if (mouseX < right && mouseX > left && mouseY > top && mouseY < bottom)
                {
                    // if there is an nback match and we have clicked correctly
                    if (placeholder.Match)
                    {
                        Core.Stats.IncrementScore_IQ(75);
                        m_justGuessedCorrect = true;
                        placeholder.MatchChecked = true;

                        Core.Stats.IncrementChanceOfPlaceholderSwitch(incrementChanceSize);

                        m_greenLightStartFlashTime = Core.Timing.TotalTime;
                        m_greenLightIsFlashing = true;

                        // add the response time to the response time list
                        Core.Stats.ResponseSpeeds.Add((Core.Timing.TotalTime - placeholder.LastSwitchTime) - placeholder.SwitchTime);
                    }

                    // we clicked incorrectly
                    else if (!placeholder.Match)
                    {
                        Core.Stats.DecrementScore_IQ(50);
                        m_justGuessedWrong = true;
                        placeholder.MatchChecked = true;

                        Core.Stats.DecrementChanceOfPlaceholderSwitch(decrementChanceSize);

                        Core.Stats.ResponseSpeeds.Add(-((Core.Timing.TotalTime - placeholder.LastSwitchTime) - placeholder.SwitchTime));

                        m_redLightStartFlashTime = Core.Timing.TotalTime;
                        m_redLightIsFlashing = true;
                    }
                }
            }
            //======================================================
        }


        /// <summary>
        /// check user input on a specified placehlder, check if its a correct guess etc
        /// </summary>
        /// <param name="placeholder">the placeholder to check input on</param>
        private void CheckInput_ServerMultIQ()
        {
            int width = Core.Graphics.DeviceManager.PreferredBackBufferWidth;
            int height = Core.Graphics.DeviceManager.PreferredBackBufferHeight;

            Vector2 worldArea = Core.Camera.GetWorldArea();

            //========= Input ======================================
            // get the keys states
            MouseState ms = Mouse.GetState();

            //We need to convert the placeholder position into screen position 
            int posX = (int)m_activePlaceholderMulti.X + (int)worldArea.X / 2;
            int posY = (int)m_activePlaceholderMulti.Y + (int)worldArea.Y / 2;

            float right = posX + (m_activePlaceholderMulti.Dimensions.X / 2);
            float left = posX - (m_activePlaceholderMulti.Dimensions.X / 2);
            float top = posY - (m_activePlaceholderMulti.Dimensions.Y / 2);
            float bottom = posY + (m_activePlaceholderMulti.Dimensions.Y / 2);

            int mouseX = GameServer.mouseX;
            int mouseY = (int)worldArea.Y - GameServer.mouseY;

            // if we are haven't checked this placeholder
            if (!m_activePlaceholderMulti.MatchChecked)
            {
                if (mouseX < right && mouseX > left && mouseY > top && mouseY < bottom)
                {
                    // if there is an nback match and we have clicked correctly
                    if (m_activePlaceholderMulti.Match)
                    {
                        Core.Stats.MultIncrementScore(Core.Net.server.whoseTurn, 75);
                        Core.Net.server.SendScoreMessage(Core.Net.server.whoseTurn);
                        m_justGuessedCorrect = true;
                        m_activePlaceholderMulti.MatchChecked = true;

                        Core.Stats.IncrementChanceOfPlaceholderSwitch(incrementChanceSize);
                    }

                    // we clicked incorrectly
                    else if (!m_activePlaceholderMulti.Match)
                    {
                        Core.Stats.MultDecrementScore(Core.Net.server.whoseTurn, 50);
                        Core.Net.server.SendScoreMessage(Core.Net.server.whoseTurn);
                        m_justGuessedWrong = true;
                        m_activePlaceholderMulti.MatchChecked = true;

                        Core.Stats.DecrementChanceOfPlaceholderSwitch(decrementChanceSize);

                        Core.Net.server.SendNotYourTurnMessage(Core.Net.server.whoseTurn);

                        // Set whose turn it is on the server
                        Core.Net.server.ChangeTurn();

                        Core.Net.server.SendYourTurnMessage(Core.Net.server.whoseTurn);
                    }
                }
            }

            // Reset the mouse positions stored on the server
            GameServer.mouseX = 0;
            GameServer.mouseY = 0;
        }

        private void CheckInput_ClientMultIQ()
        {
            MouseState ms = Mouse.GetState();

            int x = ms.X;
            int y = ms.Y;

            // if we are clicking 
            if (ms.LeftButton == ButtonState.Pressed)
            {
                Core.Net.SendInput(x, y);
            }
        }


        /// <summary>
        /// check input for the eq deconditioning game
        /// </summary>
        public void CheckInput_EQ_Decon(MediaPlaceholder placeholder)
        {
            int width = Core.Graphics.DeviceManager.PreferredBackBufferWidth;
            int height = Core.Graphics.DeviceManager.PreferredBackBufferHeight;

            Vector2 worldArea = Core.Camera.GetWorldArea();

            //========= Input ======================================
            // get the keys states
            MouseState ms = Mouse.GetState();

            //We need to convert the placeholder position into screen position 
            int posX = (int)placeholder.X + (int)worldArea.X / 2;
            int posY = (int)placeholder.Y + (int)worldArea.Y / 2;

            int mouseX = ms.X;
            int mouseY = (int)worldArea.Y - ms.Y;

            float right = posX + (placeholder.Dimensions.X / 2);
            float left = posX - (placeholder.Dimensions.X / 2);
            float top = posY - (placeholder.Dimensions.Y / 2);
            float bottom = posY + (placeholder.Dimensions.Y / 2);

            // if we are clicking on this placeholder
            if (ms.LeftButton == ButtonState.Pressed && m_displayingCorrectImage_EQ == false)
            {
                if (mouseX < right && mouseX > left && mouseY > top && mouseY < bottom)
                {
                    // if this is the placeholder showing the positive stimuli
                    if (placeholder == m_positivePlaceholder_EQ)
                    {
                        // stop updating the images
                        foreach (MediaPlaceholder m in m_placeholderList)
                        {
                            m.StopUpdating();
                        }

                        //create a temp placeholder *******************************
                        m_displayCorrectPlaceholder = new MediaPlaceholder();
                        m_displayCorrectPlaceholder.Background.Texture = m_positivePlaceholder_EQ.Background.Texture;
                        m_displayCorrectPlaceholder.Dimensions = m_positivePlaceholder_EQ.Dimensions;
                        m_displayCorrectPlaceholder.Position = m_positivePlaceholder_EQ.Position;
                        m_displayCorrectPlaceholder.Image.Texture = m_positivePlaceholder_EQ.Image.Texture;
                        m_displayCorrectPlaceholder.Frame.Texture = m_positivePlaceholder_EQ.Frame.Texture;

                        m_displayCorrectPlaceholder.Image.Alpha = 255;
                        m_displayCorrectPlaceholder.Background.Alpha = 255;
                        m_displayCorrectPlaceholder.Frame.Alpha = 255;
                        m_displayCorrectPlaceholder.StopUpdating();
                        m_displayCorrectPlaceholder.Highlighted = true;

                        //**********************************************************

                        m_displayingCorrectImage_EQ = true;
                        m_startedDisplayCorrect_EQ = Core.Timing.TotalTime;

                        Core.Stats.ResponseSpeeds.Add((Core.Timing.TotalTime - placeholder.LastSwitchTime) - placeholder.SwitchTime);

                    }
                }
            }// end of outer if
            //======================================================

        }

        /// <summary>
        /// checks collisions between all of the placeholders
        /// </summary>
        private void CheckCollisions()
        {
            foreach (MediaPlaceholder outer in m_placeholderList)
            {

                // do collision detection with other placeholders
                foreach (MediaPlaceholder inner in m_placeholderList)
                {
                    if (inner != outer)
                    {
                        // if we collide
                        if ((outer.Right > inner.Left &&
                             outer.Left < inner.Right &&
                             outer.Top > inner.Bottom &&
                             outer.Bottom < inner.Top))
                        {

                            // now resolve the collision
                            float xOverlap;
                            float yOverlap;

                            // if the gameObject lies left of the centre of the wall
                            if (outer.X < inner.X)
                            {
                                xOverlap = outer.Right - inner.Left;
                            }
                            else // it lies right of the centre
                            {
                                xOverlap = inner.Right - outer.Left;
                            }

                            // if the point is above the center of the wall
                            if (inner.Y < outer.Bottom)
                            {
                                yOverlap = outer.Bottom - inner.Top;
                            }
                            else// it lies below the centre of the wall
                            {
                                yOverlap = outer.Top - inner.Bottom;
                            }

                            float tempXoverlap = xOverlap;
                            float tempYoverlap = yOverlap;

                            // if the overlap is negative then change to positive by multiplying by -1
                            // this is only done to compare the size of the xOverlap and yOverlap,
                            // these new values are stored in temporary variables and the originals are
                            // not touched
                            if (tempXoverlap < 0)
                            {
                                tempXoverlap = -tempXoverlap;
                            }
                            if (tempYoverlap < 0)
                            {
                                tempYoverlap = -tempYoverlap;
                            }
                            //======================================================

                            // now determine which overlap is greater,
                            // we are going to move the point along the axis which
                            // has the shortest overlap.

                            if (tempXoverlap <= tempYoverlap)
                            {
                                inner.X += xOverlap;

                                // reverse the velocity and dampen it
                                inner.DirectionX = -inner.DirectionX;
                            }
                            else
                            {
                                inner.Y += yOverlap;

                                // reverse the velocity and dampen it
                                inner.DirectionY = -inner.DirectionY;
                            }

                        }
                    }
                }//end of inner for
            }// end of outer for
        }//end of check collisions

        /// <summary>
        /// initialises the image index lists associated with the placeholders
        /// forces matches based on the chance of match variable in the stats class
        /// </summary>
        /// <param name="numImages">the number of image sequences in the game</param>

        private void Create_IQ_ImageLists(int numImages)
        {
            m_imageLists = new List<List<int>>();

            m_currentImageListIndex = new List<int>();

            for (int i = 0; i < m_placeholderList.Count; i++)
            {
                // create a new list of indices for this placeholder
                m_imageLists.Add(new List<int>());
            }

            // firstly initialise to completely random values
            int count = 0;
            foreach (List<int> l in m_imageLists)
            {
                // place 50 image ineices in the list
                for (int i = 0; i <= numImages; i++)
                {
                    l.Add(Core.Random.Next(m_placeholderList[count].ImagePack.NumImages));
                }
                m_currentImageListIndex.Add(0);
                count++;
            }

            // now go through the list again and force some matches

            count = 0;
            foreach (List<int> l in m_imageLists)
            {
                for (int i = m_nback; i <= numImages; i++)
                {
                    int forceMatch = Core.Random.Next(100);

                    // if there should be a match
                    if (forceMatch <= Core.Stats.IQ_matchChance)
                    {
                        l[i] = l[i - m_nback];
                    }
                }
                count++;
            }
        }

        /// <summary>
        /// initialises the image arrays before a game, forces matches
        /// </summary>
        private void CreateImageListsMultiplayer()
        {

            m_imageLists = new List<List<int>>();

            m_currentImageListIndex = new List<int>();

            for (int i = 0; i < m_placeholderList.Count; i++)
            {
                // create a new list of indices for this placeholder
                m_imageLists.Add(new List<int>());
            }

            // firstly initialise to completely random values
            int count = 0;
            foreach (List<int> l in m_imageLists)
            {
                // place 50 image ineices in the list
                for (int i = 0; i <= m_numSequencesMult; i++)
                {
                    l.Add(Core.Random.Next(m_placeholderList[count].ImagePack.NumImages));
                }
                m_currentImageListIndex.Add(0);
                count++;
            }

            // now go through the list again and force some matches

            count = 0;
            foreach (List<int> l in m_imageLists)
            {
                for (int i = m_nback; i <= m_numSequencesMult; i++)
                {
                    int forceMatch = Core.Random.Next(100);

                    // if there should be a match
                    if (forceMatch <= Core.Stats.IQ_matchChance)
                    {
                        l[i] = l[i - m_nback];
                    }
                }
                count++;
            }
        }

        /// <summary>
        /// Creates the eq image lists for an eq game (deconditioning game)
        /// AN image pack for an eq game 
        /// </summary>
        /// <param name="numSequences">the number of sequences in the game (length of game)</param>
        /// <param name="endOfCorrectImagesIndex">the end index of the correct images int the image pack
        /// any index afterwards will be negative images</param>
        private void Create_EQ_decondition_ImageLists(int numImages)
        {
            m_imageLists = new List<List<int>>();

            m_currentImageListIndex = new List<int>();

            for (int i = 0; i < m_placeholderList.Count; i++)
            {
                // create a new list of indices for this placeholder
                m_imageLists.Add(new List<int>());
            }

            // firstly initialise to completely random values
            int count = 0;
            foreach (List<int> l in m_imageLists)
            {
                // place 50 image ineices in the list
                for (int i = 0; i <= numImages; i++)
                {
                    l.Add(Core.Random.Next(m_placeholderList[count].ImagePack.NumImages));
                }
                m_currentImageListIndex.Add(0);
                count++;
            }
        }

        /// <summary>
        /// initialises an iq game
        /// </summary>
        /// <param name="numPlaceholders">the number of placholders on screen</param>
        /// <param name="imagePack">the image pack that the placeholders are using</param>
        /// <param name="xmlContainer">a container which stores object info for the placeholders</param>
        /// <param name="numActivePlaceholders">the numbre of active placeholders in the game</param>
        /// <param name="updateSpeed">the speed in milliseconds at which the placeholder media switches</param>
        /// <param name="nback">the nback value for the game</param>
        /// <param name="numSequences">the number of media sequences in the game</param>
        public void Initialise_IQgame(int numPlaceholders, ImagePack imagePack, XmlContainer xmlContainer, int numActivePlaceholders, int updateSpeed, int nback, int numSequences)
        {

            m_placeholderList = new List<MediaPlaceholder>();

            m_nback = nback; // set nback value

            // error trapping
            if (numPlaceholders > 16)
            {
                numPlaceholders = 16;
            }
            if (numActivePlaceholders > numPlaceholders)
            {
                numActivePlaceholders = numPlaceholders;
            }

            Core.Stats.Reset_IQ(); // reset the stats of the current game

            Texture2D placeholderBackground = Core.Graphics.LoadTexture("Graphics/blank");

            // create a placeholder frame sprite
            Texture2D frameTex = Core.Graphics.LoadTexture("Graphics/Themes/Default/tempPlaceholder");

            // if there is 2 active placeholders
            Texture2D frameTex2 = Core.Graphics.LoadTexture("Graphics/Themes/Default/tempPlaceholder2");

            Vector2 initialPos = new Vector2(-150, 150);

            Vector2 dimensions = new Vector2(300, 300);

            if (numPlaceholders > 4)
            {
                initialPos.X -= 50;
                dimensions = new Vector2(225, 225);
            }
            if (numPlaceholders > 6)
            {
                dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 8)
            {
                initialPos.X -= 50;
                dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 12)
            {
                initialPos.Y += 75;
            }

            for (int i = 0; i < numPlaceholders; i++)
            {
                MediaPlaceholder p = new MediaPlaceholder();

                // read data
                p.ReadXML(xmlContainer);

                // set the dimensions
                p.Dimensions = dimensions;

                // set the position
                p.Position = initialPos;
                p.X += p.Dimensions.X * i;

                if (numPlaceholders >= 3 && numPlaceholders <= 8)
                {
                    if (i > (numPlaceholders / 2) - 1 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - (numPlaceholders / 2));
                    }
                }
                else if (numPlaceholders >= 9 && numPlaceholders <= 12)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 13)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                }
                else if (numPlaceholders >= 13 && numPlaceholders <= 16)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 12)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                    else if (i > 11 && i < 16)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 3;
                        p.X += p.Dimensions.X * (i - 12);
                    }
                }

                // set the frame texture
                p.Frame.Texture = frameTex;

                // set the blank background image
                p.Background.Texture = placeholderBackground;

                // set the image pack
                p.ImagePack = imagePack;

                // set the update speed
                p.UpdateSpeed = updateSpeed;

                // add to the list of placeholders
                AddPlaceholder(p);
            }

            // now we want to activate a number of placeholders based on the parameter passed,
            // these are chosen randomly
            int currentlyHighlighted = 1;

            while (currentlyHighlighted < numActivePlaceholders)
            {
                int randIndex = Core.Random.Next(numPlaceholders);

                if (m_placeholderList[randIndex].Highlighted == false)
                {
                    m_placeholderList[randIndex].Highlighted = true;
                    currentlyHighlighted++;
                }
                if (currentlyHighlighted > 1)
                {
                    m_placeholderList[randIndex].Frame.Texture = frameTex2;
                }

            }

            // create the image lists
            Create_IQ_ImageLists(numSequences);

            // initialise to the first image in the index lists
            for (int i = 0; i < numPlaceholders; i++)
            {
                m_placeholderList[i].Image.Texture = m_placeholderList[i].ImagePack.GetImage(m_imageLists[i][0]);
                m_currentImageListIndex[i]++;
            }
        }


        public void Server_Initialise_MultIQgame(int numPlaceholders, ImagePack imagePack, XmlContainer xmlContainer)
        {
            m_placeholderList = new List<MediaPlaceholder>();

            if (numPlaceholders > 16)
            {
                numPlaceholders = 16;
            }

            m_numPlaceholdersMulti = numPlaceholders;

            Texture2D placeholderBackground = Core.Graphics.LoadTexture("Graphics/blank");

            // create a placeholder frame sprite
            Texture2D frameTex = Core.Graphics.LoadTexture("Graphics/Themes/Default/tempPlaceholder");

            Vector2 initialPos = new Vector2(-150, 150);

            Vector2 dimensions = new Vector2(300, 300);

            if (numPlaceholders > 4)
            {
                initialPos.X -= 50;
                dimensions = new Vector2(225, 225);
            }
            if (numPlaceholders > 6)
            {
                dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 8)
            {
                initialPos.X -= 50;
                dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 12)
            {
                initialPos.Y += 75;
            }

            for (int i = 0; i < numPlaceholders; i++)
            {
                MediaPlaceholder p = new MediaPlaceholder();

                // read data
                p.ReadXML(xmlContainer);

                // set the dimensions
                p.Dimensions = dimensions;

                // set the position
                p.Position = initialPos;
                p.X += p.Dimensions.X * i;

                if (numPlaceholders >= 3 && numPlaceholders <= 8)
                {
                    if (i > (numPlaceholders / 2) - 1 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - (numPlaceholders / 2));
                    }
                }
                else if (numPlaceholders >= 9 && numPlaceholders <= 12)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 13)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                }
                else if (numPlaceholders >= 13 && numPlaceholders <= 16)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 12)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                    else if (i > 11 && i < 16)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 3;
                        p.X += p.Dimensions.X * (i - 12);
                    }
                }

                // set the frame texture
                p.Frame.Texture = frameTex;

                // set the blank background image
                p.Background.Texture = placeholderBackground;

                // set the image pack
                p.ImagePack = imagePack;

                // add to the list of placeholders
                AddPlaceholder(p);

            }
            // create the image lists
            CreateImageListsMultiplayer();

            m_serverMultIQSetUp = true;
        }

        public void Client_Initialise_MultIQgame(int numPlaceholders, ImagePack imagePack, XmlContainer xmlContainer)
        {
            // Set up separate placeholders for client
            if (numPlaceholders > 16)
            {
                numPlaceholders = 16;
            }

            m_numPlaceholdersMulti = numPlaceholders;

            Core.Stats.ResetMultiplayer();

            Texture2D placeholderBackground = Core.Graphics.LoadTexture("Graphics/blank");

            // create a placeholder frame sprite
            Texture2D frameTex = Core.Graphics.LoadTexture("Graphics/Themes/Default/tempPlaceholder");

            Vector2 initialPos = new Vector2(-150, 150);

            Vector2 dimensions = new Vector2(300, 300);

            if (numPlaceholders > 4)
            {
                initialPos.X -= 50;
                dimensions = new Vector2(225, 225);
            }
            if (numPlaceholders > 6)
            {
                dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 8)
            {
                initialPos.X -= 50;
                dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 12)
            {
                initialPos.Y += 75;
            }

            for (int i = 0; i < numPlaceholders; i++)
            {
                MediaPlaceholder p = new MediaPlaceholder();

                // read data
                p.ReadXML(xmlContainer);

                // set the dimensions
                p.Dimensions = dimensions;

                // set the position
                p.Position = initialPos;
                p.X += p.Dimensions.X * i;

                if (numPlaceholders >= 3 && numPlaceholders <= 8)
                {
                    if (i > (numPlaceholders / 2) - 1 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - (numPlaceholders / 2));
                    }
                }
                else if (numPlaceholders >= 9 && numPlaceholders <= 12)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 13)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                }
                else if (numPlaceholders >= 13 && numPlaceholders <= 16)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 12)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                    else if (i > 11 && i < 16)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 3;
                        p.X += p.Dimensions.X * (i - 12);
                    }
                }

                // set the frame texture
                p.Frame.Texture = frameTex;

                // set the blank background image
                p.Background.Texture = placeholderBackground;

                // set the image pack
                p.ImagePack = imagePack;

                p.Image.Texture = p.ImagePack.GetImage(1);

                // add to the list of client placeholders
                AddPlaceholderForClient(p);
            }

            m_clientMultIQSetUp = true;
        }

        /// <summary>
        /// reset the eq placeholders
        /// </summary>
        public void Reset_EQ_pos()
        {
            Vector2 initialPos = new Vector2(50, 150);

            if (Options.NumPlaceholders_EQ > 4)
            {
                initialPos.X -= 50;
                m_dimensions = new Vector2(225, 225);
            }
            if (Options.NumPlaceholders_EQ > 6)
            {
                m_dimensions = new Vector2(150, 150);
            }
            if (Options.NumPlaceholders_EQ > 8)
            {
                initialPos.X -= 50;
                m_dimensions = new Vector2(150, 150);
            }
            if (Options.NumPlaceholders_EQ > 12)
            {
                initialPos.Y += 75;
            }

            // reinitialise positions

            for (int i = 0; i < m_placeholderList.Count; i++)
            {
                // set the position
                m_placeholderList[i].Position = initialPos;
                m_placeholderList[i].X += m_placeholderList[i].Dimensions.X * i;

                if (Options.NumPlaceholders_EQ >= 3 && Options.NumPlaceholders_EQ <= 8)
                {
                    if (i > (Options.NumPlaceholders_EQ / 2) - 1 && i < 8)
                    {
                        m_placeholderList[i].Position = initialPos;

                        m_placeholderList[i].Y -= m_placeholderList[i].Dimensions.Y;
                        m_placeholderList[i].X += m_placeholderList[i].Dimensions.X * (i - (Options.NumPlaceholders_EQ / 2));
                    }
                }
                else if (Options.NumPlaceholders_EQ >= 9 && Options.NumPlaceholders_EQ <= 12)
                {
                    if (i > 3 && i < 8)
                    {
                        m_placeholderList[i].Position = initialPos;

                        m_placeholderList[i].Y -= m_placeholderList[i].Dimensions.Y;
                        m_placeholderList[i].X += m_placeholderList[i].Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 13)
                    {
                        m_placeholderList[i].Position = initialPos;

                        m_placeholderList[i].Y -= m_placeholderList[i].Dimensions.Y * 2;
                        m_placeholderList[i].X += m_placeholderList[i].Dimensions.X * (i - 8);
                    }
                }
                else if (Options.NumPlaceholders_EQ >= 13 && Options.NumPlaceholders_EQ <= 16)
                {
                    if (i > 3 && i < 8)
                    {
                        m_placeholderList[i].Position = initialPos;

                        m_placeholderList[i].Y -= m_placeholderList[i].Dimensions.Y;
                        m_placeholderList[i].X += m_placeholderList[i].Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 12)
                    {
                        m_placeholderList[i].Position = initialPos;

                        m_placeholderList[i].Y -= m_placeholderList[i].Dimensions.Y * 2;
                        m_placeholderList[i].X += m_placeholderList[i].Dimensions.X * (i - 8);
                    }
                    else if (i > 11 && i < 16)
                    {
                        m_placeholderList[i].Position = initialPos;

                        m_placeholderList[i].Y -= m_placeholderList[i].Dimensions.Y * 3;
                        m_placeholderList[i].X += m_placeholderList[i].Dimensions.X * (i - 12);
                    }
                }
            }
        }

        /// <summary>
        /// initialises an eq deconditioning game
        /// </summary>
        /// <param name="numPlaceholders">the number of placeholders to display media</param>
        /// <param name="posPack">Pack containing positive images for this game</param>
        /// <param name="negPack">Pack containing negative images for this game</param>
        /// <param name="xmlContainer">contains placeholder object data</param>
        /// <param name="updateSpeed">the speed at which the images change</param>
        /// <param name="numSequences">the number of sequences (length of game)</param>
        public void Initialise_EQ_decondition_game(int numPlaceholders, ImagePack posPack, ImagePack negPack, XmlContainer xmlContainer, int updateSpeed, int numSequences)
        {
            m_positiveImagePack_eq = posPack;
            m_negativeImagePack_eq = negPack;

            m_placeholderList = new List<MediaPlaceholder>();

            // error trapping
            if (numPlaceholders > 16)
            {
                numPlaceholders = 16;
            }

            m_dimensions = new Vector2(300, 300);

            Core.Stats.Reset_IQ(); // reset the stats of the current game

            Texture2D placeholderBackground = Core.Graphics.LoadTexture("Graphics/blank");

            // create a placeholder frame sprite
            Texture2D frameTex = Core.Graphics.LoadTexture("Graphics/Themes/Default/tempPlaceholder");

            Vector2 initialPos = new Vector2(50, 150);

            if (numPlaceholders > 4)
            {
                initialPos.X -= 50;
                m_dimensions = new Vector2(225, 225);
            }
            if (numPlaceholders > 6)
            {
                m_dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 8)
            {
                initialPos.X -= 50;
                m_dimensions = new Vector2(150, 150);
            }
            if (numPlaceholders > 12)
            {
                initialPos.Y += 75;
            }

            for (int i = 0; i < numPlaceholders; i++)
            {
                MediaPlaceholder p = new MediaPlaceholder();

                // read data
                p.ReadXML(xmlContainer);

                // set the dimensions
                p.Dimensions = m_dimensions;

                // set the position
                p.Position = initialPos;
                p.X += p.Dimensions.X * i;

                if (numPlaceholders >= 3 && numPlaceholders <= 8)
                {
                    if (i > (numPlaceholders / 2) - 1 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - (numPlaceholders / 2));
                    }
                }
                else if (numPlaceholders >= 9 && numPlaceholders <= 12)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 13)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                }
                else if (numPlaceholders >= 13 && numPlaceholders <= 16)
                {
                    if (i > 3 && i < 8)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y;
                        p.X += p.Dimensions.X * (i - 4);
                    }

                    else if (i > 7 && i < 12)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 2;
                        p.X += p.Dimensions.X * (i - 8);
                    }
                    else if (i > 11 && i < 16)
                    {
                        p.Position = initialPos;

                        p.Y -= p.Dimensions.Y * 3;
                        p.X += p.Dimensions.X * (i - 12);
                    }
                }

                // set the frame texture
                p.Frame.Texture = frameTex;

                // set the blank background image
                p.Background.Texture = placeholderBackground;

                // set the image pack to the negative pack as most placeholders will be using these images
                p.ImagePack = m_negativeImagePack_eq;

                // set the update speed
                p.UpdateSpeed = updateSpeed;

                // all placeholders will be highlighted during an eq game
                p.Highlighted = true;

                // add to the list of placeholders
                AddPlaceholder(p);
            }

            //now randomly select a placeholder to hold the positive stimuli
            int randIndex = Core.Random.Next(m_placeholderList.Count);
            m_positivePlaceholder_EQ = m_placeholderList[randIndex];

            m_positiveInitialPos_EQ = m_positivePlaceholder_EQ.Position;

            //set the image pack of the positive placeholder
            m_positivePlaceholder_EQ.ImagePack = m_positiveImagePack_eq;

            // create the image lists
            Create_EQ_decondition_ImageLists(numSequences);

            // initialise to the first image in the index lists
            for (int i = 0; i < numPlaceholders; i++)
            {
                m_placeholderList[i].Image.Texture = m_placeholderList[i].ImagePack.GetImage(m_imageLists[i][0]);
                m_currentImageListIndex[i]++;
            }
        }

        /// <summary>
        /// updates all iq game logic
        /// </summary>
        public void Update_iqGame()
        {
            for (int i = 0; i < m_placeholderList.Count; i++)
            {
                m_placeholderList[i].Update();

                // only check input on active placeholders
                if (m_placeholderList[i].Highlighted == true)
                {
                    CheckInput_IQ(m_placeholderList[i]);
                }

                // if this placeholders media needs to be updated 
                if (m_placeholderList[i].TimeToSwitch == true)
                {
                    // if this is an active placeholder
                    if (m_placeholderList[i].Highlighted == true)
                    {
                        m_justGuessedCorrect = false;
                        m_justGuessedWrong = false;

                        // first check that we didnt miss an nback match beforehand

                        if (m_placeholderList[i].MatchChecked == false && m_currentImageListIndex[i] > m_nback)
                        {
                            if (m_imageLists[i][m_currentImageListIndex[i] - 1] ==
                                m_imageLists[i][m_currentImageListIndex[i] - (m_nback + 1)])
                            {
                                // if we missed a match then decrement our score and the chances of a placeholder switch
                                Core.Stats.DecrementScore_IQ(50);
                                Core.Stats.DecrementChanceOfPlaceholderSwitch(decrementChanceSize);
                                Core.Stats.ResponseSpeeds.Add(-(m_placeholderList[i].UpdateSpeed));
                                m_justGuessedWrong = true;
                                m_redLightStartFlashTime = Core.Timing.TotalTime;
                                m_redLightIsFlashing = true;
                            }
                            else
                            {
                                Core.Stats.IncrementScore_IQ(2);
                            }
                        }
                        else
                        {
                            Core.Stats.IncrementScore_IQ(2);
                        }

                        // we havent made a check yet 
                        m_placeholderList[i].MatchChecked = false;

                        // get the latest image
                        m_placeholderList[i].Image.Texture = m_placeholderList[i].ImagePack.GetImage(m_imageLists[i][m_currentImageListIndex[i]]);

                        //start checking previous images
                        if (m_currentImageListIndex[i] >= m_nback)
                        {
                            // get the previous n-back image index
                            int lastNbackTex = m_imageLists[i][m_currentImageListIndex[i] - m_nback];

                            // we have a match
                            if (lastNbackTex == m_imageLists[i][m_currentImageListIndex[i]])
                            {
                                m_placeholderList[i].Match = true;
                            }
                            else
                            {
                                m_placeholderList[i].Match = false;
                            }
                        }

                        // only increment this if we havent gone over the bounds of the list
                        if (m_currentImageListIndex[i] < m_imageLists[i].Count - 1)
                        {
                            m_currentImageListIndex[i]++;
                        }
                        // if we have gone over the bounds then that means the current game is over
                        else
                        {
                            m_currentImageListIndex[i] = 0;

                            ClearPlaceholderData();

                            GuiEventHandler.QueryEvent((int)Gui.eventType.STATS);

                            break;
                        }

                        // if we should make a switch
                        if (Core.Stats.CalculatePlaceholderSwitch())
                        {
                            int randIndex = Core.Random.Next(m_placeholderList.Count);
                            MediaPlaceholder swapTo = m_placeholderList[randIndex];

                            while (swapTo.Highlighted == true)
                            {
                                randIndex = Core.Random.Next(m_placeholderList.Count);
                                swapTo = m_placeholderList[randIndex];
                            }
                            SwitchPlaceholders(m_placeholderList[i], swapTo);
                        }

                    }// end of if active placeholder
                    else // this is not the active placeholder
                    {
                        // get the latest image
                        m_placeholderList[i].Image.Texture = m_placeholderList[i].ImagePack.GetImage(m_imageLists[i][m_currentImageListIndex[i]]);

                        // only increment this if we havent gone over the bounds of the list
                        if (m_currentImageListIndex[i] < m_imageLists[i].Count - 1)
                        {
                            m_currentImageListIndex[i]++;
                        }
                        else
                        {
                            m_currentImageListIndex[i] = 0;
                        }
                    }

                }// end of needs to be updated
            }//end of for
        }

        /// <summary>
        /// updates all multiplayer iq game logic for the server
        /// </summary>
        public void Server_Update_MultIQGame()
        {
            for (int i = 0; i < m_placeholderList.Count; i++)
            {
                m_placeholderList[i].Update();

                // if a placeholder is highlighted then it is active
                if (m_placeholderList[i].Highlighted)
                {
                    m_activePlaceholderMulti = m_placeholderList[i];
                }

                CheckInput_ServerMultIQ();

                // if this placeholders media needs to be updated 
                if (m_placeholderList[i].TimeToSwitch == true)
                {
                    if (m_placeholderList[i].Highlighted)
                    {
                        m_justGuessedCorrect = false;
                        m_justGuessedWrong = false;

                        // first check that we didnt miss an nback match beforehand

                        if (m_placeholderList[i].MatchChecked == false && m_currentImageListIndex[i] > m_nback)
                        {
                            if (m_imageLists[i][m_currentImageListIndex[i] - 1] ==
                                m_imageLists[i][m_currentImageListIndex[i] - (m_nback + 1)])
                            {
                                // if we missed a match then decrement our score and the chances of a placeholder switch
                                Core.Stats.MultDecrementScore(Core.Net.server.whoseTurn, 50);
                                Core.Net.server.SendScoreMessage(Core.Net.server.whoseTurn);

                                Core.Stats.DecrementChanceOfPlaceholderSwitch(decrementChanceSize);
                                m_justGuessedWrong = true;

                                // We want to wait until justGuessedWrong has been reset to false
                                // before we tell the other player that it is now their turn
                                Core.Net.server.waitToChangeTurn = true;
                            }
                            else
                            {
                                Core.Stats.MultIncrementScore(Core.Net.server.playerOne, 2);
                                Core.Stats.MultIncrementScore(Core.Net.server.playerTwo, 2);

                                Core.Net.server.SendScoreMessage(Core.Net.server.playerOne);
                                Core.Net.server.SendScoreMessage(Core.Net.server.playerTwo);
                            }
                        }
                        else
                        {
                            Core.Stats.MultIncrementScore(Core.Net.server.playerOne, 2);
                            Core.Stats.MultIncrementScore(Core.Net.server.playerTwo, 2);

                            Core.Net.server.SendScoreMessage(Core.Net.server.playerOne);
                            Core.Net.server.SendScoreMessage(Core.Net.server.playerTwo);
                        }

                        // we havent made a check yet 
                        m_placeholderList[i].MatchChecked = false;

                        // get the latest image
                        m_placeholderList[i].Image.Texture = m_placeholderList[i].ImagePack.GetImage(m_imageLists[i][m_currentImageListIndex[i]]);

                        //start checking previous images
                        if (m_currentImageListIndex[i] >= m_nback)
                        {
                            // get the previous n-back image index
                            int lastNbackTex = m_imageLists[i][m_currentImageListIndex[i] - m_nback];

                            // we have a match
                            if (lastNbackTex == m_imageLists[i][m_currentImageListIndex[i]])
                            {
                                m_placeholderList[i].Match = true;
                            }
                            else
                            {
                                m_placeholderList[i].Match = false;
                            }
                        }

                        // only increment this if we havent gone over the bounds of the list
                        if (m_currentImageListIndex[i] < m_imageLists[i].Count - 1)
                        {
                            m_currentImageListIndex[i]++;
                        }
                        else
                        {
                            m_currentImageListIndex[i] = 0;

                            Core.Net.server.SendGameOverMessage(Core.Net.server.playerOne);
                            Core.Net.server.SendGameOverMessage(Core.Net.server.playerTwo);
                        }

                        // if we should make a switch
                        if (Core.Stats.CalculatePlaceholderSwitch())
                        {
                            int randIndex = Core.Random.Next(m_placeholderList.Count);
                            MediaPlaceholder swapTo = m_placeholderList[randIndex];

                            while (m_activePlaceholderMulti == swapTo)
                            {
                                randIndex = Core.Random.Next(m_placeholderList.Count);
                                swapTo = m_placeholderList[randIndex];
                            }
                            SwitchPlaceholders(m_activePlaceholderMulti, swapTo);
                        }

                    }// end of if active placeholder
                    else // this is not the active placeholder
                    {
                        // get the latest image
                        m_placeholderList[i].Image.Texture = m_placeholderList[i].ImagePack.GetImage(m_imageLists[i][m_currentImageListIndex[i]]);

                        // only increment this if we havent gone over the bounds of the list
                        if (m_currentImageListIndex[i] < m_imageLists[i].Count - 1)
                        {
                            m_currentImageListIndex[i]++;
                        }
                        else
                        {
                            m_currentImageListIndex[i] = 0;
                        }
                    }

                }// end of needs to be updated
            }//end of for

            if (Core.Net.server.waitToChangeTurn == true && m_justGuessedWrong == false)
            {
                Core.Net.server.SendNotYourTurnMessage(Core.Net.server.whoseTurn);

                // Set whose turn it is on the server
                Core.Net.server.ChangeTurn();

                // Inform the other player that it is now their turn
                Core.Net.server.SendYourTurnMessage(Core.Net.server.whoseTurn);

                // Reset this flag
                Core.Net.server.waitToChangeTurn = false;
            }
        }

        /// <summary>
        /// updates all multiplayer iq game logic for the server
        /// </summary>
        public void Client_Update_MultIQGame()
        {
            // update separate placeholders for client

            for (int i = 0; i < m_clientPlaceholderList.Count; i++)
            {
                m_clientPlaceholderList[i].Update();
            }

            if (Core.Net.myTurn)
            {
                CheckInput_ClientMultIQ();
            }
        }

        /// <summary>
        /// updates the eq deconditioning game
        /// </summary>
        public void Update_eqGame_decondition()
        {
            for (int i = 0; i < m_placeholderList.Count; i++)
            {
                m_placeholderList[i].Update();

                // if this placeholders media needs to be updated 
                if (m_placeholderList[i].TimeToSwitch == true)
                {
                    // get the latest image
                    m_placeholderList[i].Image.Texture = m_placeholderList[i].ImagePack.GetImage(m_imageLists[i][m_currentImageListIndex[i]]);

                    // only increment this if we havent gone over the bounds of the list
                    if (m_currentImageListIndex[i] < m_imageLists[i].Count - 1)
                    {
                        m_currentImageListIndex[i]++;

                    }
                    // if we have gone over the bounds then that means the current game is over
                    else
                    {
                        m_currentImageListIndex[i] = 0;

                        ClearPlaceholderData();

                        // head back to the main menu
                        GuiEventHandler.QueryEvent((int)Gui.eventType.STATS);

                        break;
                    }

                    // if this is the positive placeholder then we want to switch its position for the next sequence
                    if (m_placeholderList[i] == m_positivePlaceholder_EQ)
                    {
                        int randIndex = Core.Random.Next(m_placeholderList.Count);
                        MediaPlaceholder swapTo = m_placeholderList[randIndex];

                        while (swapTo == m_positivePlaceholder_EQ)
                        {
                            randIndex = Core.Random.Next(m_placeholderList.Count);
                            swapTo = m_placeholderList[randIndex];
                        }

                        SwitchPlaceholders(m_placeholderList[i], swapTo);

                        // ste the initial postion of the positive placeholder when we switch
                        m_positiveInitialPos_EQ = m_positivePlaceholder_EQ.Position;
                    }

                }// end of time to switch

                // if we are displaying a correct image that was just picked
                if (m_displayingCorrectImage_EQ)
                {

                    if (m_placeholderList[i].Image.Alpha > 0)
                    {
                        m_placeholderList[i].Image.Alpha -= 25;
                        m_placeholderList[i].Frame.Alpha -= 25;
                        m_placeholderList[i].Background.Alpha -= 25;
                    }
                    else
                    {
                        m_placeholderList[i].Image.Alpha = 0;
                        m_placeholderList[i].Frame.Alpha = 0;
                        m_placeholderList[i].Background.Alpha = 0;
                    }

                    m_placeholderList[i].Scale(0.85f);

                    if (m_displayCorrectPlaceholder != null)
                    {
                        m_displayCorrectPlaceholder.Update();

                        if (m_displayCorrectPlaceholder.Dimensions.Length() < 1000)
                        {
                            m_displayCorrectPlaceholder.Scale(1.01f);
                        }
                        if (m_displayCorrectPlaceholder.Position.Length() > 1)
                        {
                            MoveTowardCentre(m_displayCorrectPlaceholder, 3);
                        }

                        int alpha = ((m_startedDisplayCorrect_EQ + M_DISPLAY_CORRECT_TIME_EQ) - Core.Timing.TotalTime);

                        if (alpha < 255 && alpha > 0)
                        {
                            m_displayCorrectPlaceholder.Image.Alpha = alpha;
                            m_displayCorrectPlaceholder.Background.Alpha = alpha;
                            m_displayCorrectPlaceholder.Frame.Alpha = alpha;
                        }

                    }

                    // time to start updating again
                    if (Core.Timing.TotalTime > m_startedDisplayCorrect_EQ + M_DISPLAY_CORRECT_TIME_EQ)
                    {
                        foreach (MediaPlaceholder m in m_placeholderList)
                        {
                            m.ResumeUpdating();
                            m.LastSwitchTime = Core.Timing.TotalTime;
                            m.TimeToSwitch = true;
                        }
                        m_displayingCorrectImage_EQ = false;
                    }
                }
                else
                {
                    m_placeholderList[i].TimeToSwitch = false;

                    m_placeholderList[i].Image.Alpha = 255;
                    m_placeholderList[i].Frame.Alpha = 255;
                    m_placeholderList[i].Background.Alpha = 255;

                    m_placeholderList[i].Dimensions = m_dimensions;

                    m_positivePlaceholder_EQ.Position = m_positiveInitialPos_EQ;

                    m_displayCorrectPlaceholder = null;

                    // check input on each placeholder
                    CheckInput_EQ_Decon(m_placeholderList[i]);
                }
            }//end of for
        }

        /// <summary>
        /// Moves a media placeholder toward the centre of the screen
        /// </summary>
        /// <param name="m"></param>
        private void MoveTowardCentre(MediaPlaceholder m, float speed)
        {
            Vector2 screenCentre = new Vector2(0, 0);

            Vector2 direction = screenCentre - m.Position;

            direction.Normalize();

            m.Position += direction * speed;
        }

        /// <summary>
        /// removes all placeholders from placeholder list, is needed to start new games, resets all appropriate data
        /// </summary>
        private void ClearPlaceholderData()
        {
            m_placeholderList = null;
            m_imageLists = null;
            m_currentImageListIndex = null;
        }

        #endregion ===================================

    }//end of class 
}// end of namespace
