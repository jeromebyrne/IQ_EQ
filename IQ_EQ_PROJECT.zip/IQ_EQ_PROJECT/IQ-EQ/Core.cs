using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.GamerServices;
using System.Windows.Forms;

namespace IQ_EQ
{
    class Core : Microsoft.Xna.Framework.Game
    {
        #region variables -----------------------------------

        /// <summary>
        /// the graphics system
        /// </summary>
        static Graphics m_graphics = null;

        /// <summary>
        ///  the timing system
        /// </summary>
        static Timing m_timing = new Timing();

        /// <summary>
        /// the games camera
        /// </summary>
        static Camera m_camera = null;

        /// <summary> 
        /// Graphics device manager 
        /// </summary>
        static GraphicsDeviceManager m_graphics_device_manager = null;

        /// <summary>
        /// A list of all the game objects in the game
        /// </summary>
        static List<GameObject> m_gameObjects = new List<GameObject>();

        /// <summary>
        /// this manages all the media placeholders in the game at any one time
        /// </summary>
        static MediaPlaceholderManager m_placeholderManager = new MediaPlaceholderManager();

        /// <summary> 
        /// A random number generator for generating random numbers. 
        /// </summary>
        static Random m_random = new Random();

        /// <summary>
        /// the background image
        /// </summary>
        Sprite m_background = new Sprite(false,true);

        /// <summary>
        /// the tick image
        /// </summary>
        Sprite m_tick = new Sprite(false, true);

        /// <summary>
        /// the cross image
        /// </summary>
        Sprite m_cross = new Sprite(false, true);

        /// <summary>
        /// our gui, holds a number of gui screens, each gui screen holds gui widgets
        /// </summary>
        Gui m_gui = null;

        /// <summary>
        /// holds all statistics for the game such as player score etc...
        /// </summary>
        static Stats m_stats = new Stats();

        /// <summary>
        /// the different types of games that can be run
        /// </summary>
        public enum m_EnumGameType
        {
            NONE,
            IQ,
            MULT_IQ,
            EQ,
            IQ_EQ
        }

        /// <summary>
        /// the current game type being played, NONE if not in a game
        /// </summary>
        static int m_currentGameType = (int)m_EnumGameType.NONE;

        /// <summary>
        /// the last game played by the player
        /// </summary>
        static int m_lastGameType = (int)m_EnumGameType.NONE;

        /// <summary>
        /// response times for the bar graph
        /// </summary>
        BarGraph m_responseTimesBarGraph = null;

        /// <summary>
        /// Allows for networking capabilities
        /// </summary>
        static Net m_net;

        /// <summary>
        /// Are we the server?
        /// </summary>
        public static bool m_isServer = false;

        #endregion ------------------------------------------

        #region properties ----------------------------------

        /// <summary>
        /// return and sets net class
        /// </summary>
        public static Net Net { get { return m_net; } set { m_net = value; } }

        /// <summary>
        /// return the graphics sytem
        /// </summary>
        public static Graphics Graphics { get { return m_graphics; } }

        /// <summary>
        /// returns the timing system
        /// </summary>
        public static Timing Timing { get { return m_timing; } }

        /// <summary>
        /// return the game camera
        /// </summary>
        public static Camera Camera { get { return m_camera; } }

        /// <summary>
        /// returns the list of all game objects in the game
        /// </summary>
        public static List<GameObject> GameObjectsList { get { return m_gameObjects; } }

        /// <summary>
        /// returns the Placeholder manager which manages all medi placeholders in the game
        /// </summary>
        public static MediaPlaceholderManager PlaceholderManager { get { return m_placeholderManager; } }

        /// <summary>
        /// returns the random number generator
        /// </summary>
        public static Random Random { get { return m_random; } }

        /// <summary>
        /// returns the class which holds all statistics for the game
        /// </summary>
        public static Stats Stats { get { return m_stats; } }

        /// <summary>
        /// returns the current type of game being played 
        /// </summary>
        public static int CurrentGameType { get { return (int)m_currentGameType; }}

        /// <summary>
        /// returns the type of the last game played
        /// </summary>
        public static int LastGameType { get { return (int)m_lastGameType; } }

        #endregion ------------------------------------------

        #region functions -----------------------------------

        /// <summary>
        /// Constructor
        /// </summary>
        public Core()
        {

            // create a new graphics device manager

            m_graphics_device_manager = new GraphicsDeviceManager(this);

            // Set base content directory:

            Content.RootDirectory = "Content";

            // Add a new gamer services component to the game

            Components.Add(new GamerServicesComponent(this));

        }

        /// <summary>
        /// initialize our game
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();

            // create the graphics system
            m_graphics = new Graphics(m_graphics_device_manager, Content);

            // create a camera
            m_camera = new Camera();

            m_gui = new Gui();

            m_background.Texture = m_graphics.LoadTexture("Graphics/Themes/Default/background");
            m_background.Position = new Vector2(0, 0);
            m_background.Dimensions = new Vector2(200, 200);

            m_placeholderManager.Initialise();

            m_gui.BuildGui(); // initialise our gui

            if (Guide.IsVisible == false)
            {
                // let the player sign in

                Player.SignIn();
            }

        }

        /// <summary>
        /// updates the game loop
        /// </summary>
        /// <param name="gameTime">change in time</param>
        protected override void Update(Microsoft.Xna.Framework.GameTime gameTime)
        {
            base.Update(gameTime);

            if (m_net != null)
            {
                // update the net object
                m_net.Update();
            }

            // update the camera
            m_camera.Update();

            switch (m_currentGameType)
            {
                case (int)m_EnumGameType.NONE :
                {

                    break;
                }
                case (int)m_EnumGameType.IQ :
                {
                    Update_iqGame();
                    
                    break;
                }
                case (int)m_EnumGameType.MULT_IQ:
                {
                     Update_ClientMultIQGame();

                     break;
                }
                case (int)m_EnumGameType.EQ :
                {
                    Update_eqGame();

                    break;
                }
                case (int)m_EnumGameType.IQ_EQ :
                {
                    Update_iqeqGame();

                    break;
                }
            }

            m_gui.Update();
            // update our timing
            m_timing.Update(gameTime);
        }

        /// <summary>
        /// draw everything
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Draw(Microsoft.Xna.Framework.GameTime gameTime)
        {
            base.Draw(gameTime);

            // clear our screen
            m_graphics.Device.Clear(ClearOptions.Target, Color.CornflowerBlue, 0, 0);

            m_background.Width = m_camera.GetWorldArea().X;
            m_background.Height = m_camera.GetWorldArea().Y;

            switch (m_currentGameType)
            {
                case (int)m_EnumGameType.NONE:
                    {
                        m_background.Draw();

                        // if we are looking at a stats screen
                        if(Gui.m_currentScreen == (int)Gui.screen.STATS)
                        {
                            m_responseTimesBarGraph = new BarGraph("Response Times", "Trials", "Milliseconds", new Vector2(150, 150), new Vector2(40 * Core.Stats.ResponseSpeeds.Count, 300),500.0f, Core.Stats.ResponseSpeeds);
                            m_responseTimesBarGraph.Draw();

                            //float myAverage = new float();
                            //List<float>.Enumerator StatEnum = new List<float>.Enumerator();
                            //StatEnum = Core.Stats.ResponseSpeeds.GetEnumerator();
                            ////StatEnum.MoveNext();
                            //int count = 0;
                            //while(StatEnum.MoveNext())
                            //{
                            //    if (StatEnum.Current > 0)
                            //    {
                            //        myAverage += StatEnum.Current;
                            //        count++;
                            //    }
                            //}
                            //myAverage /= count;
                            //UploadScore UpS = new UploadScore();
                            //float Ratio = UpS.GetScoreRatio(myAverage);
                            //Ratio *= 10;
                            //int TempR = (int)Ratio;
                            //TempR /= 10;
                            //Ratio = (float)TempR;
                            //if (Ratio < 0)
                            //{
                            //    Ratio *= -1;
                            //    Gui.SpriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.SaveState);
                            //    Gui.OutText("Your Average Time Was ", Ratio.ToString() + "% Slower Than The Average Recorded On The Server.", 100, 100, Color.Black, 0.5f);
                            //    Gui.SpriteBatch.End();
                            //}
                            //else if (Ratio > 0)
                            //{

                            //    Gui.SpriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.SaveState);
                            //    Gui.OutText("Your Average Time Was ", Ratio.ToString() + "% Faster Than The Average Recorded On The Server.", 100, 100, Color.Black, 0.5f);
                            //    Gui.SpriteBatch.End();
                            //}
                            //else
                            //{
                                Gui.SpriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.SaveState);
                                Gui.OutText("Unable to connect to server ", "", 100, 100, Color.Black, 0.5f);
                                Gui.SpriteBatch.End();
                            //}
                        }

                        break;
                    }
                case (int)m_EnumGameType.IQ:
                    {
                        m_background.Draw();

                        m_placeholderManager.Draw_IQgame();

                        break;
                    }
                case (int)m_EnumGameType.MULT_IQ:
                    {
                        m_background.Draw();

                        m_placeholderManager.Draw_MultIQgame();

                        break;
                    }
                case (int)m_EnumGameType.EQ:
                    {
                        m_background.Draw();

                        m_placeholderManager.Draw_EQgame();

                        break;
                    }
                case (int)m_EnumGameType.IQ_EQ:
                    {
                        m_background.Draw();

                        break;
                    }
            }

            // draw the overlay last
            m_gui.Draw();

        }

        /// <summary>
        /// starts an iq game
        /// </summary>
        public static void StartIQGame()
        {
            m_currentGameType = (int)m_EnumGameType.IQ;

            // now create an image pack
            ImagePack ipack = new ImagePack(Options.ImagePackXML_IQ);

            // load object data
            XmlContainer objectData = new XmlContainer("Content/test.xml");

            // initialise the game
            m_placeholderManager.Initialise_IQgame(Options.NumPlaceholders_IQ, 
                                                   ipack, 
                                                   objectData,
                                                   Options.NumActivePlaceholders_IQ,
                                                   Options.UpdateSpeed_IQ,
                                                   Options.Nback,
                                                   Options.NumSequences_IQ);
        }

        /// <summary>
        /// starts an Multiplayer IQ game
        /// </summary>
        public static void StartMultIQGame()
        {
            if (MessageBox.Show("Do you want to be the server?", "IQ - EQ", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Core.m_isServer = true;
            }

            if (Guide.IsVisible == false)
            {
                Guide.BeginShowKeyboardInput
                (
                       PlayerIndex.One,
                       "Enter IP",
                        "Enter IP address: ",
                        "localhost",
                        Options.SetConnectingIP,
                        null
                );
            }
        }

        /// <summary>
        /// starts the multiplayer iq game for the server
        /// </summary>
        public static void StartServerMultIQGame()
        {
            // now create an image pack
            ImagePack ipack = new ImagePack("Content/ImagePack1.xml");

            // load object data
            XmlContainer objectData = new XmlContainer("Content/test.xml");

            m_placeholderManager.Server_Initialise_MultIQgame(4, ipack, objectData);
        }

        /// <summary>
        /// starts the multiplayer iq game for the client
        /// </summary>
        public static void StartClientMultIQGame()
        {
            m_currentGameType = (int)m_EnumGameType.MULT_IQ;

            // now create an image pack
            ImagePack ipack = new ImagePack("Content/ImagePack1.xml");

            // load object data
            XmlContainer objectData = new XmlContainer("Content/test.xml");

            m_placeholderManager.Client_Initialise_MultIQgame(4, ipack, objectData);
        }

        /// <summary>
        /// starts an EQ game
        /// </summary>
        public static void StartEQGame_decondition()
        {
            m_currentGameType = (int)m_EnumGameType.EQ;

            // now create 2 image packs for positive and negative stimuli
            ImagePack posPack = new ImagePack(Options.ImagePackXML_EQ_positive);

            ImagePack negPack = new ImagePack(Options.ImagePackXML_EQ_negative);

            // load object data
            XmlContainer objectData = new XmlContainer("Content/test.xml");

            // initialise the game
            m_placeholderManager.Initialise_EQ_decondition_game(Options.NumPlaceholders_EQ,
                                                                posPack,
                                                                negPack,
                                                                objectData,
                                                                Options.UpdateSpeed_EQ,
                                                                Options.NumSequences_EQ);
        }

        /// <summary>
        /// starts an IQ_EQ game
        /// </summary>
        public static void StartIQEQGame()
        {
            m_currentGameType = (int)m_EnumGameType.IQ_EQ;
        }

        /// <summary>
        /// run the iq game
        /// </summary>
        public static void Update_iqGame()
        {
            // update all the placeholders
            m_placeholderManager.Update_iqGame();
        }

        /// <summary>
        /// run the multiplayer iq game for the client
        /// </summary>
        public static void Update_ClientMultIQGame()
        {
            // update all the placeholders
            m_placeholderManager.Client_Update_MultIQGame();
        }

        /// <summary>
        /// run the eq game
        /// </summary>
        public static void Update_eqGame()
        {
            m_placeholderManager.Update_eqGame_decondition();
        }

        /// <summary>
        ///  run the iqeq game
        /// </summary>
        public static void Update_iqeqGame()
        {
        }

        // ends any type of game
        public static void EndGame()
        {
            m_currentGameType = (int)m_EnumGameType.NONE;
        }

        #endregion ------------------------------------------

    }
}
