using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace IQ_EQ
{
    /// <summary>
    /// Base class for all objects within the game
    /// </summary>
    public abstract class GameObject
    {
        #region variables ---------------------------------------
        /// <summary>
        ///  the position of this object in the game, (0,0) by default
        /// </summary>
        Vector2 m_position = new Vector2(0,0);

        /// <summary>
        /// the x,y dimensions of this object, (10,10) by default, used for collisions and sprite scaling
        /// </summary>
        Vector2 m_dimensions = new Vector2(10,10);

        /// <summary>
        /// Will this game object call its update function
        /// </summary>
        readonly bool m_updateable;

        /// <summary>
        /// will this object be seen (call its draw function)
        /// </summary>
        readonly bool m_drawable;

        /// <summary>
        /// Is this object subject to collision detection
        /// </summary>
        readonly bool m_collidable;

        /// <summary>
        /// the id of this object in the game
        /// </summary>
        int m_id = 0;

        #endregion

        #region properties ---------------------------------------

        /// <summary>
        /// set and gets the vector2 position data
        /// </summary>
        public Vector2 Position { get { return m_position; } set { m_position = value; } }
        
        /// <summary>
        /// set and get the x value of the position
        /// </summary>
        public float X { get { return m_position.X; } set { m_position.X = value; } }

        /// <summary>
        /// set and get the y value of the position
        /// </summary>
        public float Y { get { return m_position.Y; } set { m_position.Y = value; } }

        /// <summary>
        /// set and get the dimensions of this object
        /// </summary>
        public Vector2 Dimensions { get { return m_dimensions; } set { m_dimensions = value; } }

        /// <summary>
        /// set the width of this object (Dimensions.X)
        /// </summary>
        public float Width { get { return m_dimensions.X; } set { m_dimensions.X = value; } }

        /// <summary>
        /// set the height of this object (Dimensions.Y)
        /// </summary>
        public float Height { get { return m_dimensions.Y; } set { m_dimensions.Y = value; } }


        /// <summary>
        /// returns if this game object is drawable or not
        /// </summary>
        public bool IsDrawable { get { return m_drawable; } }

        /// <summary>
        /// returns if this object is updateable
        /// </summary>
        public bool IsUpdateable { get { return m_updateable; } }

        /// <summary>
        /// returns wether this object is subject to collision detection
        /// </summary>
        public bool IsCollidable { get { return m_collidable; } }

        /// <summary>
        /// returns the ID of this object in the game
        /// </summary>
        public int GetID { get { return m_id; } }

        #endregion

        #region functions ---------------------------------------

        /// <summary>
        /// All game objects need a ReadXML function even if they dont use it.
        /// Reads data from XML file and initialises the data.
        /// </summary>
        /// <param name="xmlData"> the xml container which stores all data for this object </param>
        public virtual void ReadXML(XmlContainer xmlData) 
        {
            xmlData.ReadFloat("PositionX",ref m_position.X);
            xmlData.ReadFloat("PositionY", ref m_position.Y);
            xmlData.ReadFloat("DimensionsX", ref m_dimensions.X);
            xmlData.ReadFloat("DimensionsY", ref m_dimensions.Y);
        } 

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="updateable">sets if this object will be updateable</param>
        /// <param name="drawable">sets if this object will be seen</param>
        /// <param name="drawable">sets if this object will be subject to collision detection</param>
        public GameObject(bool updateable, bool drawable, bool collidable)
        {
            m_updateable = updateable;
            m_drawable = drawable;
            m_collidable = collidable;

            // add this game object to the list of gameobjects
            Core.GameObjectsList.Add(this);

        }

        /// <summary>
        /// all game objects initialise at start up and when needed
        /// </summary>
        public virtual void Initialise()
        {
        }

        /// <summary>
        /// Update logic associated with this game object
        /// </summary>
        public virtual void Update()
        {
        }

        /// <summary>
        /// Draw this object
        /// </summary>
        public virtual void Draw()
        {
        }

        #endregion
    }
}
