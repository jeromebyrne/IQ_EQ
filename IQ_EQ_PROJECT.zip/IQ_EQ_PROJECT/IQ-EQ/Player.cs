using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework;

namespace IQ_EQ
{
    /// <summary>
    /// store information of the active player
    /// </summary>
    public static class Player
    {
        #region variables ================================================

        /// <summary>
        /// the name the player has entered
        /// </summary>
        private static string m_name = "-";


        /// <summary>
        /// Did we ask the player to enter their name
        /// </summary>
        private static bool m_asked_for_name = false;

        /// <summary>
        /// the maximum size string for a player name
        /// </summary>
        public const int MAX_NAME_LENGTH = 15;


        #endregion =======================================================

        #region properties ===============================================

        /// <summary>
        /// lets the player enter a name  
        /// </summary>
        public static void SignIn()
        {
            if (m_asked_for_name == false)
            {
                if (Guide.IsVisible == false)
                {
                   IAsyncResult res = Guide.BeginShowKeyboardInput
                        (
                            PlayerIndex.One,
                            "Sign In",
                            "Please enter your name (15 characters max): ",
                            "Jerome",
                            new AsyncCallback(OnNameEntered),
                            null
                        );
                   //Guide.EndShowKeyboardInput(res);
                }
            }
        }

        /// <summary>
        /// called when the player has entered there name at sign in
        /// </summary>
        /// <param name="result">result of the sign in operation</param>
        private static void OnNameEntered(IAsyncResult result)
        {
            // Grab the name of the user:

                m_name = Guide.EndShowKeyboardInput(result);

                // This has a nasty habit of returning null:

                if (m_name == null) m_name = "-";

                // Remove leading and trailing white space:

                m_name = m_name.Trim();

                // If the user name is longer than 15 characters then cut short:

                if (m_name.Length > MAX_NAME_LENGTH)
                {
                    // Reduce to 15 characters

                    m_name = m_name.Substring(0, MAX_NAME_LENGTH);
                }
                else if (m_name.Length <= 0)
                {
                    // If user name is not given then adopt '-' as a user name

                    m_name = "-";
                }
            
        }

        #endregion =======================================================

        #region functions ================================================



        #endregion =======================================================
    }
}
