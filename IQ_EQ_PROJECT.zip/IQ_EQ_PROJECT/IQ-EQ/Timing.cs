using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace IQ_EQ
{
    class Timing
    {
        #region variables -------------------------------------

        /// <summary>
        /// the total time in milliseconds since the application started
        /// </summary>
        int m_totalTime = 0;
        
        #endregion --------------------------------------------

        #region properties ------------------------------------

        /// <summary>
        /// returns the total time in milliseconds since the app started
        /// </summary>
        public int TotalTime { get { return m_totalTime; } }

        #endregion --------------------------------------------

        #region functions -------------------------------------

        /// <summary>
        /// update all timing variables
        /// </summary>
        /// <param name="gt">the game time</param>
        public void Update(GameTime gt)
        {
            int seconds = gt.TotalGameTime.Seconds * 1000;
            int minutes = gt.TotalGameTime.Minutes * 60000;
            int hours = gt.TotalGameTime.Hours * 3600000;

            m_totalTime = gt.TotalGameTime.Milliseconds + seconds + minutes + hours;
        }

        #endregion --------------------------------------------

    }//end of class
}// end of namespace
