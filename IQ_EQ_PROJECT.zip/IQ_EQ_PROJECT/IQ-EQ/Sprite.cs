using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace IQ_EQ
{
    /// <summary>
    /// A sprite class which inherits directly from GameObject. Draws a Texture2D.
    /// Can be scaled by changing the underlying Dimensions of the object.
    /// </summary>
    public class Sprite : GameObject
    {
        #region variables ----------------------------------

        /// <summary>
        /// the image for this object
        /// </summary>
        Texture2D m_texture = null;

        /// <summary>
        /// the normal map of the sprite if we are using normal mapping
        /// </summary>
        Texture2D m_normalMap = null;

        /// <summary>
        /// The shader effect this sprite uses to draw itself
        /// </summary>
        Effect m_effect = null;

        /// <summary>
        /// 4 vertices to draw the sprite
        /// </summary>
        VertexPositionColorTexture[] m_vertices = null;

        /// <summary>
        /// determines if the texture is flipped horizontally
        /// </summary>
        bool m_horizontalFlip = false;

        /// <summary>
        /// determines if the texture is flipped vertically
        /// </summary>
        bool m_verticalFlip = false;

        /// <summary>
        /// the alpha value fo this sprite (0 - 255)
        /// </summary>
        int m_alpha = 255;

        #endregion -----------------------------------------


        #region properties ---------------------------------

        /// <summary>
        /// gets and sets the image for this object
        /// </summary>
        public Texture2D Texture { get { return m_texture; } set { m_texture = value; } }

        /// <summary>
        /// gets and sets the normal map for this sprite
        /// </summary>
        public Texture2D NormalMap { get { return m_normalMap; } set { m_normalMap = value; } }

        /// <summary>
        /// gets and sets the shader effect the object uses to draw itself
        /// </summary>
        public Effect Effect { get { return m_effect; } set { m_effect = value; } }

        /// <summary>
        /// returns the vertices used for drawing the sprite
        /// </summary>
        protected VertexPositionColorTexture[] Vertices { get { return m_vertices; } }

        /// <summary>
        /// gets and sets the horizontal flip
        /// </summary>
        public bool HorizontalFlip { get { return m_horizontalFlip; } set { m_horizontalFlip = value; } }

        /// <summary>
        /// gets and sets the vertical flip
        /// </summary>
        public bool VerticalFlip { get {return m_verticalFlip; } set { m_verticalFlip = value; } }

        /// <summary>
        /// gets and sets the alpha value of the sprite, 0-255
        /// </summary>
        public int Alpha { get { return m_alpha; } set { m_alpha = value; } }

        #endregion -----------------------------------------



        #region functions ----------------------------------

        /// <summary>
        /// sprite constructor. all sprites are drawable
        /// </summary>
        /// <param name="updateable">sets if this sprite is updateable</param>
        /// <param name="collidable">sets if this sprite is collidable</param>
        public Sprite(bool updateable, bool collidable): base(updateable, true, collidable)
        {
            // Create the sprite's vertices
            m_vertices = new VertexPositionColorTexture[4];

            // Set the texture coordinates for each vertex:
            m_vertices[0].TextureCoordinate = Vector2.Zero;
            m_vertices[1].TextureCoordinate = Vector2.UnitY;
            m_vertices[2].TextureCoordinate = Vector2.UnitX;
            m_vertices[3].TextureCoordinate = Vector2.One;

            // Set the colors for each vertex:

            m_vertices[0].Color = Color.White;
            m_vertices[1].Color = Color.White;
            m_vertices[2].Color = Color.White;
            m_vertices[3].Color = Color.White;

            // Set z to 0
            m_vertices[0].Position.Z = 0;
            m_vertices[1].Position.Z = 0;
            m_vertices[2].Position.Z = 0;
            m_vertices[3].Position.Z = 0;

        }

        public override void ReadXML(XmlContainer xmlData)
        {
            base.ReadXML(xmlData);

            xmlData.ReadTexture("Texture",ref m_texture);
        }

        /// <summary>
        /// draw our sprite 
        /// </summary>
        public override void Draw()
        {
            base.Draw();

            // If we are missing an effect or texture then use the defaults of the graphics system
            if (m_texture == null)
            {
                m_texture = Core.Graphics.DefaultTexture;
            }
            if (m_effect == null)
            {
                m_effect = Core.Graphics.DefaultEffect;
            }
            if(m_normalMap == null)
            {
                m_normalMap = Core.Graphics.DefaultTexture;
            }
            // Get view camera transforms:

            Matrix viewProjection = Core.Camera.View * Core.Camera.Projection;

            // Take into account size of sprite
            m_vertices[0].Position.X = -(Dimensions.X / 2);
            m_vertices[1].Position.X = -(Dimensions.X / 2);
            m_vertices[2].Position.X = +(Dimensions.X / 2);
            m_vertices[3].Position.X = +(Dimensions.X / 2);

            m_vertices[0].Position.Y = +(Dimensions.Y / 2);
            m_vertices[1].Position.Y = -(Dimensions.Y / 2);
            m_vertices[2].Position.Y = +(Dimensions.Y / 2);
            m_vertices[3].Position.Y = -(Dimensions.Y / 2);

            //// Do sprite rotation:
            //Matrix rot = Matrix.CreateRotationZ(m_rotation);

            //m_vertices[0].Position = Vector3.Transform(m_vertices[0].Position, rot);
            //m_vertices[1].Position = Vector3.Transform(m_vertices[1].Position, rot);
            //m_vertices[2].Position = Vector3.Transform(m_vertices[2].Position, rot);
            //m_vertices[3].Position = Vector3.Transform(m_vertices[3].Position, rot);

            // Position the sprite
            m_vertices[0].Position.X += Position.X;
            m_vertices[1].Position.X += Position.X;
            m_vertices[2].Position.X += Position.X;
            m_vertices[3].Position.X += Position.X;

            m_vertices[0].Position.Y += Position.Y;
            m_vertices[1].Position.Y += Position.Y;
            m_vertices[2].Position.Y += Position.Y;
            m_vertices[3].Position.Y += Position.Y;

            // Decide on the texture coordinates for the sprite:

            if (m_horizontalFlip == false)
            {
                m_vertices[0].TextureCoordinate.X = 0;
                m_vertices[1].TextureCoordinate.X = 0;
                m_vertices[2].TextureCoordinate.X = 1;
                m_vertices[3].TextureCoordinate.X = 1;
            }
            else
            {
                m_vertices[0].TextureCoordinate.X = 1;
                m_vertices[1].TextureCoordinate.X = 1;
                m_vertices[2].TextureCoordinate.X = 0;
                m_vertices[3].TextureCoordinate.X = 0;
            }

            if (m_verticalFlip == false)
            {
                m_vertices[0].TextureCoordinate.Y = 0;
                m_vertices[1].TextureCoordinate.Y = 1;
                m_vertices[2].TextureCoordinate.Y = 0;
                m_vertices[3].TextureCoordinate.Y = 1;
            }
            else
            {
                m_vertices[0].TextureCoordinate.Y = 1;
                m_vertices[1].TextureCoordinate.Y = 0;
                m_vertices[2].TextureCoordinate.Y = 1;
                m_vertices[3].TextureCoordinate.Y = 0;
            }

            // Set shader parameters
            EffectParameter param_tex = m_effect.Parameters["Texture"];
            EffectParameter param_nor = m_effect.Parameters["NormalMap"];
            EffectParameter param_cam = m_effect.Parameters["CameraPosition"];
            EffectParameter param_wvp = m_effect.Parameters["WorldViewProjection"];

            if (param_tex != null) param_tex.SetValue(m_texture);
            if (param_nor != null) param_nor.SetValue(m_normalMap);
            if (param_cam != null) param_cam.SetValue(Core.Camera.Position);
            if (param_wvp != null) param_wvp.SetValue(viewProjection);

            // Begin drawing with the shader
            Effect.Begin();

            // Set vertex declaration on graphics device:
            Core.Graphics.Device.VertexDeclaration = Core.Graphics.VertexPositionColorTextureDeclaration;

            // Begin pass
            Effect.CurrentTechnique.Passes[0].Begin();

            Color color = new Color(255, 255, 255, (byte)m_alpha);

            m_vertices[0].Color = color;
            m_vertices[1].Color = color;
            m_vertices[2].Color = color;
            m_vertices[3].Color = color;

            // Draw the sprite (triangle strip)
            Core.Graphics.Device.DrawUserPrimitives<VertexPositionColorTexture>
            (
                PrimitiveType.TriangleStrip,
                m_vertices,
                0,
                2
            );

            // End pass
            Effect.CurrentTechnique.Passes[0].End();

            // End drawing with the shader:
            Effect.End();
        }

        #endregion -----------------------------------------


    }
}
