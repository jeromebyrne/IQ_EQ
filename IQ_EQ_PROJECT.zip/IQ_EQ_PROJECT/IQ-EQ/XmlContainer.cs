using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Microsoft.Xna.Framework.Graphics;

namespace IQ_EQ
{
    /// <summary>
    /// A class which holds Xml data for objects
    /// </summary>
    public class XmlContainer
    {
        #region variables ----------------------------------

        /// <summary>
        /// data node which can hold multiple sub node which contain relevant data
        /// </summary>
        XmlNode m_node = null;

        #endregion -----------------------------------------

        #region properties ---------------------------------



        #endregion -----------------------------------------

        #region functions ----------------------------------

        /// <summary>
        /// Constructor. 
        /// </summary>
        /// <param name="xmlFile">The xml file which contains the data for this container</param>
        public XmlContainer(string xmlFile)
        {
            // make sure our xml file is valid
            if (xmlFile == null) 
            {
                throw new Exception("Xml file is null");
            }

            // check that the string is not empty
            if (xmlFile.Length == 0)
            {
                throw new Exception("The xml string name is empty");
            }

            // create an xml document so we can read the data
            XmlDocument xmlDocument = new XmlDocument();

            // load:
            xmlDocument.Load(xmlFile);

            // check if this file has any nodes
            if (xmlDocument.FirstChild != null)
            {
                // if it does then save it in our node, this stores the root node which holds sub nodes
                m_node = xmlDocument.FirstChild;
            }
            else
            {
                // if it doesnt then just create a new one (will be blank)
                m_node = xmlDocument.CreateElement("Data");
            }
        }
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="node">the xml node which contains the data for this object</param>
        public XmlContainer(XmlNode node)
        {
            // dont proceed if our node is null
            if(node == null)
            {
                throw new Exception("XmlNode passed to XmlContainer constructor is null");
            }

            // assign our node
            m_node = node;

            // Remove anything that isn't an element type node:
            LinkedList<XmlNode> removeNodes = new LinkedList<XmlNode>();

            foreach (XmlNode _node in m_node.ChildNodes)
            {
                // See if this is not an element type node
                if (_node.NodeType != XmlNodeType.Element)
                {
                    removeNodes.AddLast(_node);
                }
            }

            // remove
            foreach (XmlNode _node in removeNodes)
            {
                m_node.RemoveChild(_node);
            }
        }

        /// <summary>
        /// returns the names of all the sub nodes of this node/file
        /// </summary>
        /// <returns>stores the names of the nodes in a list</returns>
        public LinkedList<string> GetNodeNames()
        {
            // create the list
            LinkedList<string> names = new LinkedList<string>();

            // traverse the nodes and add their names to the list
            foreach (XmlNode node in m_node.ChildNodes)
            {
                names.AddLast(node.Name);
            }

            return names;
        }

        /// <summary>
        /// checks if a given variable exist within the xml
        /// </summary>
        /// <param name="name"></param>
        /// <returns>return true if this variable exists, otherwise false</returns>
        public bool Contains(string name)
        {
            // if there was no name given or is empty then return
            if (name == null || name.Length <= 0)
            {
                return false;
            }

            // Try and find the variable

            XmlElement element = m_node[name];

            // if its null then its not there so just return false
            if (element == null)
            {
                return false;
            }
            // otherwise its valid so return true
            else
            {
                return true;
            } 

        }

        /// <summary>
        /// tries to read a variable from the xml and assign its value to a float
        /// </summary>
        /// <param name="name"> the name of the xml tag to be read</param>
        /// <param name="variable"> the value being assigned the info</param>
        /// <returns>returns if we were successful or not</returns>
        public bool ReadFloat(string name, ref float variable)
        {
            // if the name is null or is empty then return
            if (name == null || name.Length <= 0)
            {
                return false;
            }

            // Try and find the variable
            XmlElement element = m_node[name];

            // If the variable doesn't exist then return false
            if (element == null)
            {
                return false;
            }

            // try and convert it to a float
            float value = Convert.ToSingle(element.InnerText);

            // assign our variable this value
            variable = value;

            return true;

        }

        /// <summary>
        /// tries to read a variable from the xml and assign its value to an integer
        /// </summary>
        /// <param name="name"> the name of the xml tag to be read</param>
        /// <param name="variable"> the value being assigned the info</param>
        /// <returns>returns if we were successful or not</returns>
        public bool ReadInt(string name, ref int variable)
        {
            // check to see if the name is valid first
            if(name == null || name.Length == 0)
            {
                return false;
            }

            XmlElement element = m_node[name];

            // check if valid
            if(element == null)
            {
                return false;
            }

            // retrieve our float value
            int value = Convert.ToInt32(element.InnerText);

            variable = value;

            return true;
        }

        /// <summary>
        /// tries to read a variable name from xml and assign its value to a Texture2D
        /// </summary>
        /// <param name="name"></param>
        /// <param name="variable"></param>
        /// <returns></returns>
        public bool ReadTexture(string name, ref Texture2D variable)
        {
            // if the name is null or is empty then return
            if (name == null || name.Length <= 0)
            {
                return false;
            }

            // Try and find the variable
            XmlElement element = m_node[name];

            // If the variable doesn't exist then return false
            if (element == null)
            {
                return false;
            }

            // get the name of the texture to be loaded
            string textureName = Convert.ToString(element.InnerText);

            // now try and load the texture
            Texture2D loadedTexture = Core.Graphics.LoadTexture(textureName);

            if(loadedTexture == null)
            {
                return false;
            }
            // Assign texture
            variable = loadedTexture;

            return true;

        }

        #endregion -----------------------------------------

    }// end of class
}// end of namespace
