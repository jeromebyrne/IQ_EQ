using System;

namespace IQ_EQ
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            Core game = new Core();
            game.IsFixedTimeStep = true;
            game.TargetElapsedTime = TimeSpan.FromMilliseconds(1000.0f / 50.0f);
            game.IsMouseVisible = true;
            using (game)
            {
                game.Run();
            }
        }
    }
}

