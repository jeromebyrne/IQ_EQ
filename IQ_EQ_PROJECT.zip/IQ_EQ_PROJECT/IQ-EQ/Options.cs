using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.GamerServices;

namespace IQ_EQ
{
    /// <summary>
    /// class which holds all tweakable options for each type of game
    /// </summary>
    public static class Options
    {
        #region variables =========================================

        /// <summary>
        /// the current nback value for the iq game
        /// </summary>
        public static int m_current_nback = 2;

        /// <summary>
        /// the current number of media placeholders in an iq game
        /// </summary>
        public static int m_currentNumPlaceholders_IQ = 4;

        /// <summary>
        /// the current number of media placeholders in an eq game
        /// </summary>
        static int m_currentNumPlaceholders_EQ = 16;

        /// <summary>
        /// the current number of active placeholders in an IQ game
        /// </summary>
        public static int m_currentNumActivePlaceholders_IQ = 1;

        /// <summary>
        /// the current update speed in milliseconds for an IQ game (media switch)
        /// </summary>
        static int m_currentUpdateSpeed_IQ = 2000;

        /// <summary>
        /// the current update speed in milliseconds for an EQ game (sequence change) 
        /// </summary>
        static int m_currentUpdateSpeed_EQ = 1300;

        /// <summary>
        /// the number of media sequences in an IQ game (game length)
        /// </summary>
        static int m_numSequences_IQ = 20;

        /// <summary>
        /// the number of sequences in an EQ game (game length)
        /// </summary>
        static int m_numSequences_EQ = 20;

        /// <summary>
        /// the directory of the xml file containing image pack info for the IQ game
        /// </summary>
        static string m_imagePackXML_IQ = "Content/ImagePack1.xml";

        /// <summary>
        /// the directory of the xml file containing image pack info for the positive stimuli in the EQ game
        /// </summary>
        static string m_imagePackXML_EQ_positive = "Content/DogsCatsPack.xml";

        /// <summary>
        /// the directory of the xml file containing image pack info for the negative stimuli in the EQ game
        /// </summary>
        static string m_imagePackXML_EQ_negative = "Content/SpiderPack.xml";

        #endregion ================================================

        #region properties ========================================

        /// <summary>
        /// returns the current nback value
        /// </summary>
        public static int Nback { get { return m_current_nback; } }

        /// <summary>
        /// returns the current number of placeholders in an IQ game
        /// </summary>
        public static int NumPlaceholders_IQ { get { return m_currentNumPlaceholders_IQ; } }

        /// <summary>
        /// returns the current number of placeholders in an EQ game
        /// </summary>
        public static int NumPlaceholders_EQ { get { return m_currentNumPlaceholders_EQ; } }

        /// <summary>
        /// returns the number of active placeholders in an IQ game
        /// </summary>
        public static int NumActivePlaceholders_IQ { get { return m_currentNumActivePlaceholders_IQ; } }

        /// <summary>
        /// returns the current update speed for an IQ game
        /// </summary>
        public static int UpdateSpeed_IQ { get { return m_currentUpdateSpeed_IQ; } }

        /// <summary>
        /// returns the update speed for an eq game
        /// </summary>
        public static int UpdateSpeed_EQ { get { return m_currentUpdateSpeed_EQ; } }

        /// <summary>
        /// returns the number of sequences in an IQ game (game Length)
        /// </summary>
        public static int NumSequences_IQ { get { return m_numSequences_IQ; } }

        /// <summary>
        /// returns the number of sequences in an EQ game (game Length)
        /// </summary>
        public static int NumSequences_EQ { get { return m_numSequences_EQ; } }

        /// <summary>
        /// returns the directory to the xml file containing the image pack info for an IQ game
        /// </summary>
        public static string ImagePackXML_IQ { get { return m_imagePackXML_IQ; } }

        /// <summary>
        /// returns the directory to the xml file containing the image pack info for an EQ game - positive stimuli
        /// </summary>
        public static string ImagePackXML_EQ_positive { get { return m_imagePackXML_EQ_positive; } }

        /// <summary>
        /// returns the directory to the xml file containing the image pack info for an EQ game - negative stimuli
        /// </summary>
        public static string ImagePackXML_EQ_negative { get { return m_imagePackXML_EQ_negative; } }

        #endregion ================================================

        #region functions =========================================

        /// <summary>
        /// sets the nback value for the iq game
        /// </summary>
        /// <param name="result"> the result of the input box</param>
        public static void Set_Nback_IQ(IAsyncResult result)
        {

            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "2";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if(value.Length > 1 || value.Length <= 0)
            {
                value = "2";
            }

            m_current_nback = int.Parse(value);

        }

        /// <summary>
        /// Sets the number of placeholders in an IQ game based on user input
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetNumPLaceholders_IQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "4";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length > 2 || value.Length <= 0)
            {
                value = "16";
            }

            m_currentNumPlaceholders_IQ = int.Parse(value);

            if (m_currentNumPlaceholders_IQ <= 0)
            {
                m_currentNumPlaceholders_IQ = 1;
            }
        }

        /// <summary>
        /// Sets the number of placeholders in an EQ game based on user input
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetNumPLaceholders_EQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "4";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length > 2 || value.Length <= 0)
            {
                value = "16";
            }

            m_currentNumPlaceholders_EQ = int.Parse(value);

            if(m_currentNumPlaceholders_EQ <= 0)
            {
                m_currentNumPlaceholders_EQ = 1;
            }
        }

        /// <summary>
        /// Sets the number of active placeholders in an IQ game based on user input
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetNumActivePLaceholders_IQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "1";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length > 2 || value.Length <= 0)
            {
                value = "16";
            }

            m_currentNumActivePlaceholders_IQ = int.Parse(value);

            if (m_currentNumActivePlaceholders_IQ <= 0)
            {
                m_currentNumActivePlaceholders_IQ = 1;
            }
        }

        /// <summary>
        /// Sets the update speed in an IQ game based on user input
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetUpdateSpeed_IQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "2000";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length <= 0)
            {
                value = "2000";
            }

            m_currentUpdateSpeed_IQ = int.Parse(value);

            if (m_currentUpdateSpeed_IQ <= 0)
            {
                m_currentUpdateSpeed_IQ = 1;
            }
        }

        /// <summary>
        /// Sets the update speed in an EQ game based on user input
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetUpdateSpeed_EQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "2000";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length <= 0)
            {
                value = "2000";
            }

            m_currentUpdateSpeed_EQ = int.Parse(value);

            if (m_currentUpdateSpeed_EQ <= 0)
            {
                m_currentUpdateSpeed_EQ = 1;
            }
        }

        /// <summary>
        /// Sets the number of sequences in a IQ game (game length)
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetNumSequences_IQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "20";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length <= 0)
            {
                value = "20";
            }

            m_numSequences_IQ = int.Parse(value);

            if (m_numSequences_IQ <= 0)
            {
                m_numSequences_IQ = 1;
            }
        }

        /// <summary>
        /// Sets the number of sequences in a EQ game (game length)
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetNumSequences_EQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "20";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length <= 0)
            {
                value = "20";
            }

            m_numSequences_EQ = int.Parse(value);

            if (m_numSequences_EQ <= 0)
            {
                m_numSequences_EQ = 1;
            }
        }

        /// <summary>
        /// Sets the directory of the image pack xml file in a IQ game (game length)
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetImageXML_IQ(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "Content/ImagePack1.xml";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length <= 0)
            {
                value = "Content/ImagePack1.xml";
            }

            m_imagePackXML_IQ = value;
        }

        /// <summary>
        /// Sets the directory of the image pack xml file in a EQ game (game length)
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetImageXML_EQ_positive(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "Content/ImagePack1.xml";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length <= 0)
            {
                value = "Content/ImagePack1.xml";
            }

            m_imagePackXML_EQ_positive = value;
        }

        /// <summary>
        /// Sets the directory of the image pack xml file in a EQ game (game length)
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetImageXML_EQ_negative(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // This has a nasty habit of returning null:

            if (value == null) value = "Content/ImagePack1.xml";

            // Remove leading and trailing white space:

            value = value.Trim();

            // we only want a single digit number 
            if (value.Length <= 0)
            {
                value = "Content/ImagePack1.xml";
            }

            m_imagePackXML_EQ_negative = value;
        }

        /// <summary>
        /// Set the IP for the client to connect to
        /// </summary>
        /// <param name="result">the result from the user input</param>
        public static void SetConnectingIP(IAsyncResult result)
        {
            string value = Guide.EndShowKeyboardInput(result);

            // Temp mult game
            Core.Net = new Net(value);

            Core.Net.SendStartGameMessage();

            Core.Net.ipIsSet = true;
        }

        #endregion
    }
}
