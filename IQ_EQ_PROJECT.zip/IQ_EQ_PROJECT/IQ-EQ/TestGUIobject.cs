using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace IQ_EQ
{
    public class TestGUIobject
    {
        SpriteBatch spriteBatch;

        public Vector2 position = new Vector2(0,0);

        public Rectangle bounds = new Rectangle();

        Texture2D texture;

        public TestGUIobject()
        {
            spriteBatch = new SpriteBatch(Core.Graphics.Device);

            texture = Core.Graphics.LoadTexture("meh");
        }

        public void Draw()
        {
            // position the rectangle around the position
            bounds.X = 500;
            bounds.Y = 50;

            bounds.Width = 200;
            bounds.Height = 200;


            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.BackToFront, SaveStateMode.SaveState);

            spriteBatch.Draw(texture, bounds, Color.White);

            spriteBatch.End();
        }
    }
}
