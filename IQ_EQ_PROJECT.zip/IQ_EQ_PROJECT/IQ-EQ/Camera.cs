using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace IQ_EQ
{
    /// <summary>
    /// Camera class, 2D view, camera will usually remain static
    /// </summary>
    public class Camera : GameObject
    {
        #region variables ------------------------------

        /// <summary>
        /// camera world matrix, inverse of view matrix
        /// </summary>
        Matrix m_world;

        /// <summary>
        /// camera view matrix
        /// </summary>
        Matrix m_view ;

        /// <summary>
        /// camera projection matrix
        /// </summary>
        Matrix m_projection;

        /// <summary>
        /// the view area of the camera, view area is 1280x720 by default
        /// </summary>
        Vector2 m_viewArea = new Vector2(1280,720);

        #endregion -------------------------------------

        #region properties -----------------------------

        /// <summary>
        /// returns the camera's world matrix
        /// </summary>
        public Matrix World { get { return m_world; } }

        /// <summary>
        /// returns the camera's view matrix
        /// </summary>
        public Matrix View { get { return m_view; } }

        /// <summary>
        /// returns the camera's projection matrix;
        /// </summary>
        public Matrix Projection { get { return m_projection; } }

        #endregion -------------------------------------

        #region functions ------------------------------

        /// <summary>
        /// Camera constructor, camera is updateable but not drawable or collidable
        /// </summary>
        public Camera() : base(true, false, false)
        {
            
        }

        /// <summary>
        /// update the camera's world, view, projection matrices 
        /// </summary>
        public override void Update()
        {
            base.Update();

            // set the view area equal to the back buffer width and height
            //m_viewArea.X = Core.Graphics.DeviceManager.PreferredBackBufferWidth;
            //m_viewArea.Y = Core.Graphics.DeviceManager.PreferredBackBufferHeight;

            // update our world matrix
           m_world =  Matrix.CreateTranslation(Position.X,Position.Y,0);

           // update our view (inverse of world)
           m_view = Matrix.CreateTranslation(-Position.X, -Position.Y, 0);

           Vector2 screen_area = GetWorldArea();

           // Calculate the projection matrix, (orthographic projection)
           m_projection = Matrix.CreateOrthographic
           (
               screen_area.X,
               screen_area.Y,
               0,
               1000
           );

        }

        //=========================================================================================
        /// <summary>
        /// Returns the area of the game level that will be shown according to the current 
        /// display settings of the game. On widescreen displays the area will be different 
        /// than to a 4:3 display. On widescreen, more of the level is shown.
        /// </summary>
        /// <returns> Area of the screen that will be shown for the current display settings. </returns>
        //=========================================================================================

        public Vector2 GetWorldArea()
        {
            // Get the current screen resolution:
            int width = Core.Graphics.Device.Viewport.Width;
            int height = Core.Graphics.Device.Viewport.Height;

            // Calculate the aspect ratio:
            float aspect = (float)(width) / (float)(height);

            // Calculate the reference aspect ratio:
            float reference_aspect = (float)(m_viewArea.X) / (float)(m_viewArea.Y);

            // Calculate the area we will show when widescreen adjustments are taken into account
            float screen_area_x = ((float)(m_viewArea.X) / reference_aspect) * aspect;
            float screen_area_y = m_viewArea.Y;

            // Return the area of the level that will be shown by the screen
            return new Vector2(screen_area_x, screen_area_y);
        }

        #endregion -------------------------------------

    }// end of class
}// end of namespace
