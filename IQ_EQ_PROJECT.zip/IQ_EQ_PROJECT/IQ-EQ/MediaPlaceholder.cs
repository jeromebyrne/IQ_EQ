using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace IQ_EQ
{
    /// <summary>
    /// A class which is capable of displaying sprites, playing videos and also audio. 
    /// All media placeholders are capable of shifting between media types e.g video to audio.
    /// </summary>
    public class MediaPlaceholder : GameObject
    {
        #region variables -------------------------------------------------

        /// <summary>
        /// the index of this particular placeholder among the others
        /// </summary>
        int m_placeHolderIndex;

        /// <summary>
        /// the direction the placeholder is moving
        /// </summary>
        Vector2 m_direction = new Vector2(0,0);

        /// <summary>
        /// the speed at which the placeholder is moving 
        /// </summary>
        float m_speed = 0;

        /// <summary>
        /// the placeholder frame image
        /// </summary>
        Sprite m_frame = null;

        /// <summary>
        /// the speed at which this object updates (in milliseconds)
        /// </summary>
        int m_updateSpeed = 0;

        /// <summary>
        /// the time that this object last updated its media
        /// </summary>
        int m_lastUpdateTime = 0;

        /// <summary>
        /// do we need to be updated?
        /// </summary>
        bool m_needToBeUpdated = false;

        //is this placeholder highlighted
        bool m_highLighted = false;

        /// <summary>
        /// the different types of media that a placeholder can use
        /// </summary>
        protected enum m_EnumMediaType
        {
            IMAGE,
            VIDEO,
            AUDIO
        }

        /// <summary>
        /// the media type that this placeholder is currently displaying/playing
        /// </summary>
        int m_currentMediaType = (int)m_EnumMediaType.IMAGE;

        /// <summary>
        /// the image to display when the media type is image
        /// </summary>
        Sprite m_image = null;

        /// <summary>
        /// the video to play when the media type is video
        /// </summary>
        VideoElement m_video = null;

        /// <summary>
        /// the audio to play when the media type is audio 
        /// </summary>
        AudioElement m_audio = null;

        /// <summary>
        /// the current image pack that the placeholder is using
        /// </summary>
        ImagePack m_currentImagePack = null;


        #endregion -------------------------------------------------------------

        #region properties -----------------------------------------------------

        /// <summary>
        /// gets and sets the index of this particular placeholder
        /// </summary>
        public int Index { get { return m_placeHolderIndex; } set { m_placeHolderIndex = value; } }

        /// <summary>
        /// get and set the x,y direction
        /// </summary>
        public Vector2 Direction { get { return m_direction; } set { m_direction = value; } }

        /// <summary>
        /// get and set the x direction
        /// </summary>
        public float DirectionX { get { return m_direction.X; } set { m_direction.X = value; } }

        /// <summary>
        /// get and set the y direction
        /// </summary>
        public float DirectionY { get { return m_direction.Y; } set { m_direction.Y = value; } }

        /// <summary>
        /// get and set the speed of the placeholder
        /// </summary>
        public float Speed { get { return m_speed; } set { m_speed = value; } }

        /// <summary>
        /// gets and sets the placeholder frame image
        /// </summary>
        public Sprite Frame { get { return m_frame; } set { m_frame = value; } }

        /// <summary>
        /// get and set the image which is displayed when the media type is IMAGE
        /// </summary>
        public Sprite Image { get { return m_image; } set { m_image = value; } }

        /// <summary>
        /// Is this placeholder highlighted? can set true or false
        /// </summary>
        public bool Highlighted { get { return m_highLighted; } set { m_highLighted = value; } }


        /// <summary>
        /// get and set the video which is displayed when the media type is VIDEO
        /// </summary>
        public VideoElement Video { get { return m_video; } set { m_video = value; } }

        /// <summary>
        /// get and set the audio which is played when the media type is AUDIO
        /// </summary>
        public AudioElement Audio { get { return m_audio; } set { m_audio = value; } }

        /// <summary>
        /// gets and sets the current image pack that this placeholder is using
        /// </summary>
        public ImagePack ImagePack { get { return m_currentImagePack; } set { m_currentImagePack = value; } }

        /// <summary>
        /// returns the left x coordinates of the placeholder
        /// </summary>
        public float Left { get { return Position.X - Dimensions.X / 2; } }

        /// <summary>
        /// returns the right x coordinates of the placeholder
        /// </summary>
        public float Right { get { return Position.X + Dimensions.X / 2; } }

        /// <summary>
        /// returns the top y coordinates of the placeholder
        /// </summary>
        public float Top { get { return Position.Y + Dimensions.Y / 2; } }

        /// <summary>
        /// returns the top y coordinates of the placeholder
        /// </summary>
        public float Bottom { get { return Position.Y - Dimensions.Y / 2; } }

        #endregion -------------------------------------------------------------

        #region functions ------------------------------------------------------

        /// <summary>
        /// constructor
        /// </summary>
        public MediaPlaceholder(): base(true, true, true)
        {
            // add to the list of placeholders
            Core.PlaceholderManager.AddPlaceholder(this);

            // create our sprite image
            m_image = new Sprite(true, false);

            // create our placeholder frame image
            m_frame = new Sprite(true, true);

        }

        /// <summary>
        /// read all of our data for this object
        /// </summary>
        /// <param name="xmlData">the container storing the xml data</param>
        public override void ReadXML(XmlContainer xmlData)
        {
            // read the data for this gameObject
            base.ReadXML(xmlData);

            xmlData.ReadFloat("DirectionX", ref m_direction.X);
            xmlData.ReadFloat("DirectionY", ref m_direction.Y);
            xmlData.ReadFloat("Speed", ref m_speed);
            xmlData.ReadInt("UpdateSpeed", ref m_updateSpeed);

            // read the xml for our sprite
            m_image.ReadXML(xmlData);

        }
        /// <summary>
        /// scales the dimensions by the given value
        /// </summary>
        /// <param name="value">the amount to scale by</param>
        public void Scale(float value)
        {
            Dimensions = Dimensions * value;
   
        }

        /// <summary>
        /// update all of our logic here
        /// </summary>
        public override void Update()
        {
            base.Update();

            // update our position
            Position += m_direction * m_speed;

            // make sure our placeholder image is where our placeholder is
            m_image.Position = this.Position;
            m_image.Dimensions = this.Dimensions;

            // update our frame image position and dimensions
            m_frame.Position = this.Position;
            m_frame.Dimensions = this.Dimensions;

            // ======= collision detection with window ==========================

            float maxX = Core.Camera.Position.X + (Core.Camera.GetWorldArea().X/2);
            float maxY = Core.Camera.Position.Y + (Core.Camera.GetWorldArea().Y/2);

            if(Position.X - (Dimensions.X / 2) < -maxX)
            {
                DirectionX = 1;
            }
            else if (Position.X + (Dimensions.X / 2) > maxX)
            {
                DirectionX = -1;
            }

            if (Position.Y - (Dimensions.Y / 2) < -maxY)
            {
                DirectionY = 1;
            }
            else if (Position.Y + (Dimensions.Y / 2) > maxY)
            {
                DirectionY = -1;
            }

            //=======================================================

            //====== Timing =========================================
            int totaltime = Core.Timing.TotalTime;

            int elapsed = totaltime - m_lastUpdateTime;

            // if we need to update
            if (elapsed >= m_updateSpeed)
            {
                // we need to be updated
                m_needToBeUpdated = true;

                // we have updated so store the current update time
                m_lastUpdateTime = Core.Timing.TotalTime;
            }
            //======================================================

        }
        /// <summary>
        /// returns true if we need to be updated
        /// </summary>
        /// <returns></returns>
        public bool NeedToBeUpdated()
        {
            bool result = m_needToBeUpdated;

            m_needToBeUpdated = false;

            return result;
        }
        /// <summary>
        /// displays the current media type
        /// </summary>
        public override void Draw()
        {
            base.Draw();

            // display/play our current media type
            PlayCurrentMedia();

            // draw the frame for the placeholder if it is highlighted
            if(m_highLighted)
            {
                m_frame.Draw();
            }
            
        }

        /// <summary>
        /// plays the current media type of the placeholder, if a media type is selected but there is no media of that type
        /// then it will try to default to the displaying an image (if no image is provided the graphics system default will be displayed)
        /// </summary>
        private void PlayCurrentMedia()
        {
            // if the placeholder wants to display an image
            if (m_currentMediaType == (int)m_EnumMediaType.IMAGE)
            {
                // draw the current image sprite
                m_image.Draw();
            }
            // if we want to play audio
            else if (m_currentMediaType == (int)m_EnumMediaType.AUDIO)
            {
                // check that our audio element is not null
                if (m_audio == null)
                {
                    // if it is then lets default to image
                    m_currentMediaType = (int)m_EnumMediaType.IMAGE;
                }
                // else play our audio
                else
                {
                }
            }
            // if we want to display video
            else if (m_currentMediaType == (int)m_EnumMediaType.VIDEO)
            {
                // if our video element is null...
                if (m_video == null)
                {
                    //... then default to image
                    m_currentMediaType = (int)m_EnumMediaType.IMAGE;
                }
                // else play our video
                else
                {
                }
            }
        }
        #endregion -------------------------------------------------------------
    }// end of class
}// end of namespace
