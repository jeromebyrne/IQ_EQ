using System;
using System.Collections.Generic;
using System.Text;

using IQ_EQ.GetRatio;

namespace IQ_EQ
{
    class UploadScore
    {
        public UploadScore()
        { }
        public float GetScoreRatio(float nScore)
        {
            GetRatio.Service1 oService = new IQ_EQ.GetRatio.Service1();
            //WebProxy proxy = new WebProxy(m_ProxyPort, true);
            //proxy.Credentials = new NetworkCredential("c00101741","", "itcarlow");
            //oService.Proxy = proxy;

            float value = 0;

            try
            {
                value = 100 - oService.GetScoreRatio(nScore);
            }
            catch
            {
                value = 0;
            }
            return value;
        }
    }
}
////Gav IP 149.153.122.94
//// Port :1506