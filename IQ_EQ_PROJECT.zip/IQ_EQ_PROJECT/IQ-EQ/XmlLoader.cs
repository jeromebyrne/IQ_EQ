using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace IQ_EQ
{
    public class XmlLoader
    {
        // a hash which maps from class names to XMLConstruction functions
        static Dictionary<string, ConstructorInfo> m_constructors = null;

        public static void Initialise()
        {
            m_constructors = new Dictionary<string, ConstructorInfo>();

            // Get the all the types needed for this registration process
            // all GameObjects use xml
            Type xmlType = Type.GetType("IQ_EQ.GameObject");

            // do not proceed if we cannot find this object type
            if (xmlType == null)
            {
                return;
            }

            // get all class types in the game
            Module[] modules = Assembly.GetCallingAssembly().GetModules();

            // traverse
            foreach (Module module in modules)
            {
                // Get the module types
                Type[] types = module.GetTypes();

                foreach (Type type in types)
                {
                    // Try and see if the type derives from xmlType (GameObject) or is abstract: if so then abort
                    if (type.IsSubclassOf(xmlType) == false || type.IsAbstract) return;

                    //TODO: finish this when aware of surroundings and not about to pass out
                }

            }

        }
    }// end of class
}// end of namespace
