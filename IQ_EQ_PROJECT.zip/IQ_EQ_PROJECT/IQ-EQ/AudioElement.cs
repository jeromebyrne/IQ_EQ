using System;
using System.Collections.Generic;
using System.Text;

namespace IQ_EQ
{
    public class AudioElement
    {
    }
}
