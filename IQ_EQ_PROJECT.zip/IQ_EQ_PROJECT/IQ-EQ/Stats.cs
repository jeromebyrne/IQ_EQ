using System;
using System.Collections.Generic;
using System.Text;

namespace IQ_EQ
{
    /// <summary>
    /// a simple class which stores information such as scores, averages etc...
    /// </summary>
    public class Stats
    {
        #region variables ======================================================

        /// <summary>
        /// the players score for the current IQ game
        /// </summary>
        int m_score_IQ = 0;

        /// <summary>
        /// the players score for the last IQ game
        /// </summary>
        int m_lastScore_IQ = 0;

        /// <summary>
        /// the players score for the current EQ game
        /// </summary>
        int m_score_EQ = 0;

        /// <summary>
        /// the players score for the last EQ game
        /// </summary>
        int m_lastScore_EQ = 0;

        /// <summary>
        /// the players score for the current game
        /// </summary>
        int m_mult_score_playerOne = 0;

        /// <summary>
        /// the players score for the current game
        /// </summary>
        int m_mult_score_playerTwo = 0;

        /// <summary>
        /// the chance of the active placeholder switching
        /// </summary>
        int m_chanceOfPlaceholderSwitch = 40;

        /// <summary>
        /// the highscore
        /// </summary>
        int m_highScore_IQ = 0;

        /// <summary>
        /// the chance of there being a match in nback images
        /// </summary>
        int m_iqMatchChance = 45;

        /// <summary>
        /// stores the response speeds of the player in the IQ game
        /// </summary>
        List<float> m_responseSpeed = new List<float>();


        #endregion =============================================================

        #region properties =====================================================

        /// <summary>
        /// returns the response speeds of the player
        /// </summary>
        public List<float> ResponseSpeeds { get { return m_responseSpeed; } }

        /// <summary>
        /// Returns the players Score for an IQ game
        /// </summary>
        public int Score_IQ { get { return m_score_IQ; } set { m_score_IQ = value; } }

        /// <summary>
        /// returns the score for the current EQ game
        /// </summary>
        public int Score_EQ { get { return m_score_EQ; } }

        /// <summary>
        /// Returns player one's Score for multiplayer
        /// </summary>
        public int MultScorePlayerOne { get { return m_mult_score_playerOne; } }

        /// <summary>
        /// Returns player two's Score for multiplayer
        /// </summary>
        public int MultScorePlayerTwo { get { return m_mult_score_playerTwo; } }

        /// <summary>
        /// the score for the last IQ game
        /// </summary>
        public int LastScore_IQ { get { return m_lastScore_IQ; } }

        /// <summary>
        /// the score for the last EQ game
        /// </summary>
        public int LastScore_EQ { get { return m_lastScore_EQ; } }

        /// <summary>
        /// rwturn the chance of an iq nback image match. Used for determining when building image lists
        /// </summary>
        public int IQ_matchChance { get { return m_iqMatchChance; } }

        /// <summary>
        /// returns the chance (0-100) of a placeholder switch
        /// </summary>
        public int ChanceOfPlaceholderSwitch { get { return m_chanceOfPlaceholderSwitch; } }

        /// <summary>
        /// get and set the highscore for the IQ game
        /// </summary>
        public int HighScore_IQ { get { return m_highScore_IQ; } set { m_highScore_IQ = value; } }


        #endregion =============================================================

        #region functions ======================================================

        /// <summary>
        /// constructor
        /// </summary>
        public Stats()
        {
        }

        /// <summary>
        /// increments the score by a certain value
        /// </summary>
        /// <param name="value">the amount to increment by</param>
        public void IncrementScore_IQ(int value)
        {
            m_score_IQ += value;
        }

        /// <summary>
        /// increments a player's score by a certain value , in multiplayer
        /// </summary>
        /// <param name="value">the amount to increment by</param>
        public void MultIncrementScore(int player, int value)
        {
            if (player == 0)
            {
                m_mult_score_playerOne += value;
            }

            else
            {
                m_mult_score_playerTwo += value;
            }
        }

        /// <summary>
        /// decrement a player's score by a certain value , in multiplayer
        /// </summary>
        /// <param name="value">the amount to decrement by</param>
        public void MultDecrementScore(int player, int value)
        {
            if (player == 0)
            {
                m_mult_score_playerOne -= value;
            }

            else
            {
                m_mult_score_playerTwo -= value;
            }
        }

        /// <summary>
        /// decrement the score
        /// </summary>
        /// <param name="value">the amount to decrement by</param>
        public void DecrementScore_IQ(int value)
        {
            m_score_IQ -= value;
        }

        /// <summary>
        /// increments the chance of a placeholder switch
        /// </summary>
        /// <param name="value"></param>
        public void IncrementChanceOfPlaceholderSwitch(int value)
        {
            m_chanceOfPlaceholderSwitch += value;

            if (m_chanceOfPlaceholderSwitch > 100)
            {
                m_chanceOfPlaceholderSwitch = 100;
            }
        }

        public void DecrementChanceOfPlaceholderSwitch(int value)
        {
            m_chanceOfPlaceholderSwitch -= value;

            if (m_chanceOfPlaceholderSwitch < 0)
            {
                m_chanceOfPlaceholderSwitch = 0;
            }
        }

        /// <summary>
        /// calculates wether the active placeholder should switch
        /// </summary>
        /// <returns></returns>
        public bool CalculatePlaceholderSwitch()
        {
            bool result = false;

            int randNum = Core.Random.Next(101);

            if (randNum < m_chanceOfPlaceholderSwitch)
            {
                result = true;
            }

            return result;
        }

        /// <summary>
        /// resets most stats, keeps highscore
        /// </summary>
        /// <returns></returns>
        public void Reset_IQ()
        {
            m_score_IQ = 0;
            m_chanceOfPlaceholderSwitch = 0;
        }

        /// <summary>
        /// resets the response speed list to store nothing
        /// </summary>
        public void ResetResponseSpeeds()
        {
            m_responseSpeed = new List<float>();
        }

        /// <summary>
        /// resets most stats, keeps highscore
        /// </summary>
        /// <returns></returns>
        public void ResetMultiplayer()
        {
            m_score_IQ = 0;
            m_chanceOfPlaceholderSwitch = 0;
        }

        

        #endregion =============================================================



    }
}
