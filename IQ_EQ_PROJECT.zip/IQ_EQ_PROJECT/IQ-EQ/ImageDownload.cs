using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Net;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace IQ_EQ
{
    class ImageDownload
    {
        #region variables ===========================================
        /// <summary>
        /// The WebClient.
        /// </summary>
        private WebClient m_Client = new WebClient();
        /// <summary>
        /// The WebProxy:port
        /// </summary>
        private string m_ProxyPort = "Default";
        /// <summary>
        /// The username to access the internet
        /// </summary>
        private string m_UserName = "Default";
        /// <summary>
        /// the password associated with the User
        /// </summary>
        private string m_PassWord = "Default";
        /// <summary>
        /// the domain the User is regesterd under.
        /// </summary>
        private string m_Domain = "Default";


        #endregion ===================================================
        #region properties ===========================================



        #endregion ===================================================
        #region functions ===========================================
        /// <summary>
        /// construction
        /// </summary>
        /// <param name="ProxyPort"></param>
        /// <param name="UserName"></param>
        /// <param name="PassWord"></param>
        /// <param name="Domain"></param>
        public ImageDownload(string ProxyPort,string UserName,string PassWord,string Domain)
        {
            m_ProxyPort = ProxyPort;
            m_UserName = UserName;
            m_PassWord = PassWord;
            m_Domain = Domain;
            //Set up the Proxy Credentials
            WebProxy proxy = new WebProxy(m_ProxyPort, true);
            proxy.Credentials = new NetworkCredential(m_UserName, m_PassWord, m_Domain);
            m_Client.Proxy = proxy;
        }
        /// <summary>
        /// Download any file from a URL, it will be saved to the Debug/Release folder
        /// </summary>
        /// <param name="Uri"></param>
        /// <param name="SaveAs"></param>
        
        public Texture2D BeginDownload(string Uri,string SaveAs)
        {
            try
            {
                Uri Addr = new Uri(Uri);
                m_Client.DownloadFile(Addr, SaveAs);
                return Texture2D.FromFile(Core.Graphics.Device, SaveAs); 
            }
            catch(WebException WE)
            {
                Console.WriteLine(WE.ToString());
                return Texture2D.FromFile(Core.Graphics.Device, "Graphics/DefaultTexture");
            }
        }
       
        #endregion ===================================================
    }
}
